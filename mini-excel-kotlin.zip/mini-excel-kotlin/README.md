# Mini Excel — نسخة مصغرة من Excel (Kotlin)

تطبيق أندرويد بسيط بلغة Kotlin و Jetpack Compose، بنفس شكل Excel:
شريط علوي أخضر، تبويبات Ribbon (Home / Insert / View)، شريط صيغة،
عناوين أعمدة A, B, C… وعناوين صفوف 1, 2, 3…، وخلايا قابلة للكتابة والتنسيق.

## بدون معادلات أو رسوم بيانية أو مخططات
- كتابة نصوص وأرقام في الخلايا
- تنسيق: Bold / Italic / Underline، حجم الخط، لون النص، لون الخلفية، محاذاة
- إضافة صف / إضافة عمود، مسح خلية، مسح الكل
- إظهار / إخفاء خطوط الشبكة
- حفظ وفتح ملف CSV من خلال New / Open / Save

## التشغيل على GitHub
1. أنشئ مستودع جديد على GitHub وارفع محتويات هذا المجلد (كل الملفات).
2. افتح تبويب **Actions** في المستودع.
3. سيعمل ملف `.github/workflows/build.yml` تلقائيًا ويبني التطبيق.
4. بعد انتهاء البناء، حمّل ملف APK من قسم **Artifacts** باسم `mini-excel-debug-apk`.
5. ثبّت ملف `app-debug.apk` على هاتف أندرويد.

يمكنك أيضًا تشغيل البناء يدويًا من تبويب Actions بزر **Run workflow**.

## التشغيل محليًا
```bash
./gradlew assembleDebug
```
ملف APK سيكون في:
`app/build/outputs/apk/debug/app-debug.apk`

## المتطلبات
- Android Studio Hedgehog أو أحدث
- JDK 17
- Gradle 8.5 (موجود مع المشروع عبر Gradle Wrapper)
- compileSdk 34 / minSdk 24 / targetSdk 34
- Kotlin 1.9.22 / Jetpack Compose BOM 2024.02.00

## بنية المشروع
```
settings.gradle.kts
build.gradle.kts
gradle.properties
gradlew / gradlew.bat
gradle/wrapper/
.github/workflows/build.yml
app/
  build.gradle.kts
  src/main/AndroidManifest.xml
  src/main/java/com/miniexcel/
    MainActivity.kt            # الواجهة: الشريط، التبويبات، شريط الصيغة، الشبكة
    SpreadsheetViewModel.kt    # حالة الجدول والخلايا والحفظ CSV
  src/main/res/values/
    strings.xml / colors.xml / themes.xml
```
