package com.miniexcel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.ViewModel

data class CellData(
    val text: String = "",
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val align: TextAlign = TextAlign.Left,
    val textColor: Long = 0xFF000000L,
    val fillColor: Long = 0xFFFFFFFFL,
    val fontSize: Int = 14
)

class SpreadsheetViewModel : ViewModel() {
    var rowCount by mutableIntStateOf(50)
        private set
    var colCount by mutableIntStateOf(15)
        private set
    var selectedRow by mutableIntStateOf(0)
        private set
    var selectedCol by mutableIntStateOf(0)
        private set
    var showGridlines by mutableStateOf(true)
    var activeTab by mutableStateOf("Home")

    private val _cells = mutableStateMapOf<Pair<Int, Int>, CellData>()
    val cells: Map<Pair<Int, Int>, CellData> get() = _cells

    fun cellAt(row: Int, col: Int): CellData = _cells[row to col] ?: CellData()

    fun selectedCell(): CellData = cellAt(selectedRow, selectedCol)

    fun setSelected(row: Int, col: Int) {
        if (row in 0 until rowCount && col in 0 until colCount) {
            selectedRow = row
            selectedCol = col
        }
    }

    fun updateSelected(transform: (CellData) -> CellData) {
        val key = selectedRow to selectedCol
        _cells[key] = transform(cellAt(selectedRow, selectedCol))
    }

    fun setSelectedText(text: String) {
        updateSelected { it.copy(text = text) }
    }

    fun toggleBold() = updateSelected { it.copy(bold = !it.bold) }
    fun toggleItalic() = updateSelected { it.copy(italic = !it.italic) }
    fun toggleUnderline() = updateSelected { it.copy(underline = !it.underline) }

    fun setAlign(align: TextAlign) = updateSelected { it.copy(align = align) }
    fun setTextColor(color: Long) = updateSelected { it.copy(textColor = color) }
    fun setFillColor(color: Long) = updateSelected { it.copy(fillColor = color) }
    fun increaseFont() = updateSelected { it.copy(fontSize = (it.fontSize + 2).coerceAtMost(28)) }
    fun decreaseFont() = updateSelected { it.copy(fontSize = (it.fontSize - 2).coerceAtLeast(10)) }

    fun addRow() { rowCount += 1 }
    fun addColumn() { colCount += 1 }
    fun clearSelected() { _cells.remove(selectedRow to selectedCol) }
    fun clearAll() { _cells.clear() }

    fun colName(col: Int): String {
        var n = col
        var s = ""
        do {
            s = ('A' + (n % 26)).toString() + s
            n = n / 26 - 1
        } while (n >= 0)
        return s
    }

    fun cellRef(): String = "${colName(selectedCol)}${selectedRow + 1}"

    fun toCsv(): String {
        val sb = StringBuilder()
        for (r in 0 until rowCount) {
            var lastNonEmpty = -1
            for (c in 0 until colCount) {
                if (cellAt(r, c).text.isNotBlank()) lastNonEmpty = c
            }
            if (lastNonEmpty < 0) {
                sb.append("\n")
                continue
            }
            for (c in 0..lastNonEmpty) {
                if (c > 0) sb.append(",")
                sb.append(escapeCsv(cellAt(r, c).text))
            }
            sb.append("\n")
        }
        return sb.toString().trimEnd('\n') + "\n"
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }

    fun loadCsv(text: String) {
        _cells.clear()
        val lines = text.split("\n")
        for ((r, line) in lines.withIndex()) {
            if (r >= rowCount) break
            if (line.isEmpty()) continue
            val values = parseCsvLine(line)
            for ((c, v) in values.withIndex()) {
                if (c >= colCount) break
                if (v.isNotEmpty()) _cells[r to c] = CellData(text = v)
            }
        }
        selectedRow = 0
        selectedCol = 0
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && inQuotes && i + 1 < line.length && line[i + 1] == '"' -> {
                    cur.append('"'); i += 2
                }
                ch == '"' -> { inQuotes = !inQuotes; i++ }
                ch == ',' && !inQuotes -> { out.add(cur.toString()); cur = StringBuilder(); i++ }
                else -> { cur.append(ch); i++ }
            }
        }
        out.add(cur.toString())
        return out
    }
}
