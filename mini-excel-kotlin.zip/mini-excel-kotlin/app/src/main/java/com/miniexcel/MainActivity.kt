package com.miniexcel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

val ExcelGreen = Color(0xFF217346)
val ExcelGreenDark = Color(0xFF185C37)
val HeaderGrey = Color(0xFFE7E6E6)
val LightGrey = Color(0xFFF3F3F3)
val GridGrey = Color(0xFFD4D4D4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = ExcelGreen,
                    secondary = ExcelGreenDark
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    MiniExcelScreen()
                }
            }
        }
    }
}

@Composable
fun MiniExcelScreen(vm: SpreadsheetViewModel = viewModel()) {
    val context = LocalContext.current
    var fileName by remember { mutableStateOf("Book1") }
    var status by remember { mutableStateOf("جاهز") }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(vm.toCsv().toByteArray(Charsets.UTF_8))
                }
                status = "تم الحفظ: $fileName.csv"
            } catch (e: Exception) {
                status = "خطأ في الحفظ"
            }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                }.orEmpty()
                vm.loadCsv(text)
                status = "تم فتح الملف"
            } catch (e: Exception) {
                status = "خطأ في فتح الملف"
            }
        }
    }

    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    val selected = vm.selectedCell()

    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        // ---- Top title bar, Excel green ----
        Row(
            modifier = Modifier.fillMaxWidth().height(48.dp)
                .background(ExcelGreen).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Mini Excel",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = fileName, color = Color.White, fontSize = 14.sp)
            Spacer(modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.clearAll(); status = "ملف جديد" }) {
                Text("New", color = Color.White)
            }
            TextButton(onClick = { openLauncher.launch(arrayOf("text/csv", "text/*")) }) {
                Text("Open", color = Color.White)
            }
            TextButton(onClick = { saveLauncher.launch("$fileName.csv") }) {
                Text("Save", color = Color.White)
            }
        }

        // ---- Ribbon tabs ----
        Row(
            modifier = Modifier.fillMaxWidth().background(LightGrey)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (tab in listOf("Home", "Insert", "View")) {
                val isActive = vm.activeTab == tab
                Text(
                    text = tab,
                    modifier = Modifier
                        .clickable { vm.activeTab = tab }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .border(
                            width = if (isActive) 2.dp else 0.dp,
                            color = if (isActive) ExcelGreen else Color.Transparent
                        )
                        .padding(horizontal = 2.dp),
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = if (isActive) ExcelGreenDark else Color.Black,
                    fontSize = 14.sp
                )
            }
        }

        // ---- Ribbon content ----
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (vm.activeTab) {
                "Home" -> {
                    RibbonButton("B", selected.bold) { vm.toggleBold() }
                    RibbonButton("I", selected.italic) { vm.toggleItalic() }
                    RibbonButton("U", selected.underline) { vm.toggleUnderline() }
                    RibbonButton("A-", false) { vm.decreaseFont() }
                    Text("${selected.fontSize}", fontSize = 14.sp)
                    RibbonButton("A+", false) { vm.increaseFont() }
                    RibbonButton("◀", selected.align == TextAlign.Left) {
                        vm.setAlign(TextAlign.Left)
                    }
                    RibbonButton("■", selected.align == TextAlign.Center) {
                        vm.setAlign(TextAlign.Center)
                    }
                    RibbonButton("▶", selected.align == TextAlign.Right) {
                        vm.setAlign(TextAlign.Right)
                    }
                    // Text colours
                    ColorDot(Color.Black, selected.textColor == 0xFF000000L) {
                        vm.setTextColor(0xFF000000L)
                    }
                    ColorDot(Color.Red, selected.textColor == 0xFFFF0000L) {
                        vm.setTextColor(0xFFFF0000L)
                    }
                    ColorDot(Color.Blue, selected.textColor == 0xFF0000FFL) {
                        vm.setTextColor(0xFF0000FFL)
                    }
                    ColorDot(Color(0xFF217346), selected.textColor == 0xFF217346L) {
                        vm.setTextColor(0xFF217346L)
                    }
                    // Fill colours
                    ColorDot(Color.Yellow, selected.fillColor == 0xFFFFFF00L) {
                        vm.setFillColor(0xFFFFFF00L)
                    }
                    ColorDot(Color(0xFFC6EFCE), selected.fillColor == 0xFFC6EFCEL) {
                        vm.setFillColor(0xFFC6EFCEL)
                    }
                    ColorDot(Color(0xFFDDEBF7), selected.fillColor == 0xFFDDEBF7L) {
                        vm.setFillColor(0xFFDDEBF7L)
                    }
                    ColorDot(Color.White, selected.fillColor == 0xFFFFFFFFL) {
                        vm.setFillColor(0xFFFFFFFFL)
                    }
                    Button(onClick = { vm.clearSelected() }) {
                        Text("Clear cell")
                    }
                }
                "Insert" -> {
                    Button(onClick = { vm.addRow(); status = "تمت إضافة صف" }) {
                        Text("Add Row")
                    }
                    Button(onClick = { vm.addColumn(); status = "تمت إضافة عمود" }) {
                        Text("Add Column")
                    }
                    Button(onClick = { vm.clearSelected() }) {
                        Text("Clear Cell")
                    }
                    Button(onClick = { vm.clearAll(); status = "تم مسح الجدول" }) {
                        Text("Clear All")
                    }
                }
                "View" -> {
                    Text("Gridlines", fontSize = 14.sp)
                    Switch(
                        checked = vm.showGridlines,
                        onCheckedChange = { vm.showGridlines = it }
                    )
                    Text(
                        "${vm.rowCount} rows  •  ${vm.colCount} cols",
                        fontSize = 14.sp
                    )
                }
            }
        }

        // ---- Formula bar ----
        Row(
            modifier = Modifier.fillMaxWidth().background(LightGrey)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.width(64.dp).height(36.dp)
                    .background(Color.White).border(1.dp, GridGrey),
                contentAlignment = Alignment.Center
            ) {
                Text(vm.cellRef(), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("fx", fontSize = 14.sp, fontStyle = FontStyle.Italic, color = ExcelGreenDark)
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = selected.text,
                onValueChange = { vm.setSelectedText(it) },
                modifier = Modifier.weight(1f).height(48.dp),
                singleLine = true,
                placeholder = { Text("اكتب هنا في الخلية المحددة…") }
            )
        }

        // ---- Column headers ----
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(hScroll)
                .background(HeaderGrey)
        ) {
            Box(
                modifier = Modifier.width(48.dp).height(28.dp)
                    .border(0.5.dp, GridGrey),
                contentAlignment = Alignment.Center
            ) { Text("") }
            for (c in 0 until vm.colCount) {
                Box(
                    modifier = Modifier.width(110.dp).height(28.dp)
                        .border(0.5.dp, GridGrey),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        vm.colName(c),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // ---- Grid ----
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth()
                .verticalScroll(vScroll)
                .horizontalScroll(hScroll)
        ) {
            Column {
                for (r in 0 until vm.rowCount) {
                    Row {
                        Box(
                            modifier = Modifier.width(48.dp).height(36.dp)
                                .background(HeaderGrey)
                                .border(0.5.dp, GridGrey),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${r + 1}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        for (c in 0 until vm.colCount) {
                            val cell = vm.cellAt(r, c)
                            val isSelected = r == vm.selectedRow && c == vm.selectedCol
                            Box(
                                modifier = Modifier.width(110.dp).height(36.dp)
                                    .background(Color(cell.fillColor))
                                    .border(
                                        width = if (isSelected) 2.dp else 0.5.dp,
                                        color = if (isSelected) ExcelGreen else GridGrey
                                    )
                                    .clickable { vm.setSelected(r, c) }
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = cell.text,
                                    fontSize = cell.fontSize.sp,
                                    fontWeight = if (cell.bold) FontWeight.Bold else FontWeight.Normal,
                                    fontStyle = if (cell.italic) FontStyle.Italic else FontStyle.Normal,
                                    textDecoration = if (cell.underline) TextDecoration.Underline else TextDecoration.None,
                                    color = Color(cell.textColor),
                                    textAlign = cell.align,
                                    maxLines = 1,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---- Status bar ----
        Row(
            modifier = Modifier.fillMaxWidth().height(28.dp)
                .background(LightGrey).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Cell: ${vm.cellRef()}", fontSize = 12.sp)
            Spacer(modifier = Modifier.width(16.dp))
            Text(status, fontSize = 12.sp, color = ExcelGreenDark)
            Spacer(modifier = Modifier.weight(1f))
            Text("Mini Excel • بدون معادلات أو رسوم بيانية", fontSize = 12.sp)
        }
    }
}

@Composable
fun RibbonButton(label: String, active: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) ExcelGreen else Color(0xFFE7E6E6),
            contentColor = if (active) Color.White else Color.Black
        )
    ) {
        Text(label, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ColorDot(color: Color, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier.width(28.dp).height(28.dp)
            .background(color)
            .border(
                width = if (active) 3.dp else 1.dp,
                color = if (active) ExcelGreen else GridGrey
            )
            .clickable { onClick() }
    )
}
