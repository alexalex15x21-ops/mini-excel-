const ROWS = 100;
const COLS = 26; // A to Z

const DEFAULT_CELL_STATE = {
    value: "",
    bold: false,
    italic: false,
    underline: false,
    align: "left",
    fontFamily: "Calibri, sans-serif",
    fontSize: "14",
    textColor: "#000000",
    bgColor: "#ffffff"
};

// Application State
let sheetsDB = JSON.parse(localStorage.getItem("mini_excel_db")) || {
    "Sheet 1": {}
};
let currentSheetName = Object.keys(sheetsDB)[0];
let activeCellId = "A1";

// DOM Elements
const colHeadersEl = document.getElementById("col-headers");
const rowHeadersEl = document.getElementById("row-headers");
const cellsGridEl = document.getElementById("cells-grid");
const cellAddressInput = document.getElementById("cell-address");
const cellContentBar = document.getElementById("cell-content-bar");
const sheetsListEl = document.getElementById("sheets-list");

// Formatting Controls
const fontFamilySelect = document.getElementById("font-family");
const fontSizeSelect = document.getElementById("font-size");
const btnBold = document.getElementById("btn-bold");
const btnItalic = document.getElementById("btn-italic");
const btnUnderline = document.getElementById("btn-underline");
const btnAlignLeft = document.getElementById("btn-align-left");
const btnAlignCenter = document.getElementById("btn-align-center");
const btnAlignRight = document.getElementById("btn-align-right");
const bgColorPicker = document.getElementById("bg-color");
const textColorPicker = document.getElementById("text-color");

// Helper: Convert column index (0-25) to letter (A-Z)
function getColLetter(colIndex) {
    return String.fromCharCode(65 + colIndex);
}

// Initialize Grid DOM
function initGrid() {
    // 1. Build Column Headers (A-Z)
    for (let c = 0; c < COLS; c++) {
        const colHeader = document.createElement("div");
        colHeader.className = "col-header";
        colHeader.id = `col-header-${getColLetter(c)}`;
        colHeader.textContent = getColLetter(c);
        colHeadersEl.appendChild(colHeader);
    }

    // 2. Build Row Headers (1-100) & Cells
    for (let r = 1; r <= ROWS; r++) {
        const rowHeader = document.createElement("div");
        rowHeader.className = "row-header";
        rowHeader.id = `row-header-${r}`;
        rowHeader.textContent = r;
        rowHeadersEl.appendChild(rowHeader);

        const rowEl = document.createElement("div");
        rowEl.className = "cell-row";

        for (let c = 0; c < COLS; c++) {
            const cellId = `${getColLetter(c)}${r}`;
            const cellEl = document.createElement("div");
            cellEl.className = "cell";
            cellEl.id = cellId;
            cellEl.contentEditable = true;
            cellEl.spellcheck = false;
            cellEl.dataset.row = r;
            cellEl.dataset.col = c;

            // Events
            cellEl.addEventListener("focus", () => selectCell(cellId));
            cellEl.addEventListener("input", () => {
                updateCellData(cellId, { value: cellEl.innerText });
                cellContentBar.value = cellEl.innerText;
            });
            cellEl.addEventListener("keydown", (e) => handleKeyNavigation(e, r, c));

            rowEl.appendChild(cellEl);
        }
        cellsGridEl.appendChild(rowEl);
    }
}

// Get or Initialize Cell State in Current Sheet
function getCellData(cellId) {
    const sheet = sheetsDB[currentSheetName];
    if (!sheet[cellId]) {
        return { ...DEFAULT_CELL_STATE };
    }
    return { ...DEFAULT_CELL_STATE, ...sheet[cellId] };
}

// Save Cell Data & Persist to LocalStorage
function updateCellData(cellId, newProps) {
    const currentData = getCellData(cellId);
    sheetsDB[currentSheetName][cellId] = { ...currentData, ...newProps };
    localStorage.setItem("mini_excel_db", JSON.stringify(sheetsDB));
}

// Apply Visual Styles to a DOM Cell
function applyCellStylesToDOM(cellId) {
    const cellEl = document.getElementById(cellId);
    if (!cellEl) return;
    const data = getCellData(cellId);

    cellEl.innerText = data.value;
    cellEl.style.fontWeight = data.bold ? "bold" : "normal";
    cellEl.style.fontStyle = data.italic ? "italic" : "normal";
    cellEl.style.textDecoration = data.underline ? "underline" : "none";
    cellEl.style.textAlign = data.align;
    cellEl.style.fontFamily = data.fontFamily;
    cellEl.style.fontSize = `${data.fontSize}px`;
    cellEl.style.color = data.textColor;
    cellEl.style.backgroundColor = data.bgColor;
}

// Select a Cell and Sync Toolbar UI
function selectCell(cellId) {
    // Remove previous active states
    document.querySelectorAll(".cell.active").forEach(el => el.classList.remove("active"));
    document.querySelectorAll(".col-header.highlight, .row-header.highlight").forEach(el => el.classList.remove("highlight"));

    activeCellId = cellId;
    const cellEl = document.getElementById(cellId);
    if (!cellEl) return;

    cellEl.classList.add("active");
    cellAddressInput.value = cellId;

    // Highlight Headers
    const colLetter = cellId.match(/[A-Z]+/)[0];
    const rowNum = cellId.match(/\d+/)[0];
    document.getElementById(`col-header-${colLetter}`)?.classList.add("highlight");
    document.getElementById(`row-header-${rowNum}`)?.classList.add("highlight");

    // Sync Toolbar UI with Cell Data
    const data = getCellData(cellId);
    cellContentBar.value = data.value;
    fontFamilySelect.value = data.fontFamily;
    fontSizeSelect.value = data.fontSize;
    bgColorPicker.value = data.bgColor;
    textColorPicker.value = data.textColor;

    btnBold.classList.toggle("active", data.bold);
    btnItalic.classList.toggle("active", data.italic);
    btnUnderline.classList.toggle("active", data.underline);

    btnAlignLeft.classList.toggle("active", data.align === "left");
    btnAlignCenter.classList.toggle("active", data.align === "center");
    btnAlignRight.classList.toggle("active", data.align === "right");
}

// Keyboard Arrow & Enter Navigation
function handleKeyNavigation(e, row, col) {
    let targetRow = row;
    let targetCol = col;

    if (e.key === "Enter") {
        e.preventDefault();
        targetRow = Math.min(ROWS, row + 1);
    } else if (e.key === "Tab") {
        e.preventDefault();
        targetCol = Math.min(COLS - 1, col + 1);
    } else if (e.key === "ArrowDown") {
        targetRow = Math.min(ROWS, row + 1);
    } else if (e.key === "ArrowUp") {
        targetRow = Math.max(1, row - 1);
    } else {
        return;
    }

    const nextCellId = `${getColLetter(targetCol)}${targetRow}`;
    document.getElementById(nextCellId)?.focus();
}

// Content Bar Sync
cellContentBar.addEventListener("input", () => {
    const cellEl = document.getElementById(activeCellId);
    if (cellEl) {
        cellEl.innerText = cellContentBar.value;
        updateCellData(activeCellId, { value: cellContentBar.value });
    }
});

// Toolbar Event Listeners
btnBold.addEventListener("click", () => {
    const data = getCellData(activeCellId);
    updateCellData(activeCellId, { bold: !data.bold });
    applyCellStylesToDOM(activeCellId);
    selectCell(activeCellId);
});

btnItalic.addEventListener("click", () => {
    const data = getCellData(activeCellId);
    updateCellData(activeCellId, { italic: !data.italic });
    applyCellStylesToDOM(activeCellId);
    selectCell(activeCellId);
});

btnUnderline.addEventListener("click", () => {
    const data = getCellData(activeCellId);
    updateCellData(activeCellId, { underline: !data.underline });
    applyCellStylesToDOM(activeCellId);
    selectCell(activeCellId);
});

[
    { btn: btnAlignLeft, align: "left" },
    { btn: btnAlignCenter, align: "center" },
    { btn: btnAlignRight, align: "right" }
].forEach(({ btn, align }) => {
    btn.addEventListener("click", () => {
        updateCellData(activeCellId, { align });
        applyCellStylesToDOM(activeCellId);
        selectCell(activeCellId);
    });
});

fontFamilySelect.addEventListener("change", (e) => {
    updateCellData(activeCellId, { fontFamily: e.target.value });
    applyCellStylesToDOM(activeCellId);
});

fontSizeSelect.addEventListener("change", (e) => {
    updateCellData(activeCellId, { fontSize: e.target.value });
    applyCellStylesToDOM(activeCellId);
});

bgColorPicker.addEventListener("input", (e) => {
    updateCellData(activeCellId, { bgColor: e.target.value });
    applyCellStylesToDOM(activeCellId);
});

textColorPicker.addEventListener("input", (e) => {
    updateCellData(activeCellId, { textColor: e.target.value });
    applyCellStylesToDOM(activeCellId);
});

// Render Current Sheet Data
function renderSheet() {
    // Reset all cells
    for (let r = 1; r <= ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
            const cellId = `${getColLetter(c)}${r}`;
            applyCellStylesToDOM(cellId);
        }
    }
    selectCell("A1");
    document.getElementById("A1")?.focus();
}

// Render Sheet Tabs
function renderSheetTabs() {
    sheetsListEl.innerHTML = "";
    Object.keys(sheetsDB).forEach(sheetName => {
        const tab = document.createElement("div");
        tab.className = `sheet-tab ${sheetName === currentSheetName ? "active" : ""}`;
        tab.textContent = sheetName;
        tab.addEventListener("click", () => {
            currentSheetName = sheetName;
            renderSheetTabs();
            renderSheet();
        });
        sheetsListEl.appendChild(tab);
    });
}

// Add New Sheet
document.getElementById("btn-add-sheet").addEventListener("click", () => {
    const newIndex = Object.keys(sheetsDB).length + 1;
    const newSheetName = `Sheet ${newIndex}`;
    sheetsDB[newSheetName] = {};
    currentSheetName = newSheetName;
    localStorage.setItem("mini_excel_db", JSON.stringify(sheetsDB));
    renderSheetTabs();
    renderSheet();
});

// Clear Current Sheet
document.getElementById("btn-clear").addEventListener("click", () => {
    if (confirm(`Are you sure you want to clear all data in "${currentSheetName}"?`)) {
        sheetsDB[currentSheetName] = {};
        localStorage.setItem("mini_excel_db", JSON.stringify(sheetsDB));
        renderSheet();
    }
});

// Export to CSV
document.getElementById("btn-export").addEventListener("click", () => {
    let csvContent = "";
    for (let r = 1; r <= ROWS; r++) {
        let rowValues = [];
        let hasDataInRow = false;
        for (let c = 0; c < COLS; c++) {
            const cellId = `${getColLetter(c)}${r}`;
            const val = getCellData(cellId).value.replace(/"/g, '""');
            if (val !== "") hasDataInRow = true;
            rowValues.push(`"${val}"`);
        }
        if (hasDataInRow) {
            csvContent += rowValues.join(",") + "\n";
        }
    }

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${currentSheetName}.csv`;
    a.click();
    URL.revokeObjectURL(url);
});

// Import from CSV
document.getElementById("file-import").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const lines = event.target.result.split(/\r?\n/);
        sheetsDB[currentSheetName] = {};

        lines.forEach((line, rIndex) => {
            if (rIndex >= ROWS || !line.trim()) return;
            const cols = line.split(",").map(item => item.replace(/^"|"$/g, ""));
            cols.forEach((val, cIndex) => {
                if (cIndex < COLS && val !== "") {
                    const cellId = `${getColLetter(cIndex)}${rIndex + 1}`;
                    updateCellData(cellId, { value: val });
                }
            });
        });
        renderSheet();
    };
    reader.readAsText(file);
});

// Boot App
initGrid();
renderSheetTabs();
renderSheet();
