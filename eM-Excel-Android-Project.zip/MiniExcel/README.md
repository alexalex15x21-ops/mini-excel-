# eM Excel for Android

eM Excel is an offline-first Android spreadsheet editor written in Kotlin with Jetpack Compose and a small MVVM layer. It uses Android's Storage Access Framework (SAF), so the user chooses the documents the app may read or write. The app manifest deliberately contains **no `INTERNET` permission**.

## Included features

- Open and save `.xlsx`, `.xls`, and `.csv` documents through Android's document picker.
- Create new `.xlsx` and `.csv` documents.
- Multiple worksheets in `.xlsx` and `.xls`: switch, add, rename, and delete.
- Two-axis spreadsheet grid with a fixed row-number rail and column headers.
- Edit/clear cell values; insert/delete rows and columns.
- Basic bold and background fill formatting. These attributes are written for Excel workbooks.
- Global search over files that have been opened or explicitly added through **Add files to global search**. Results include the file, sheet, row, column, and cell preview.
- A staged save process: serialize to a temporary file, parse it for validation, keep a private pre-save recovery copy when one exists, write through SAF, and reopen the written document for verification.

## Project structure

```text
MiniExcel/
├── app/
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/miniexcel/app/
│       │   │   ├── MainActivity.kt
│       │   │   ├── MiniExcelApplication.kt
│       │   │   ├── data/
│       │   │   │   ├── CsvCodec.kt
│       │   │   │   ├── LocalFileIndex.kt
│       │   │   │   ├── SpreadsheetRepository.kt
│       │   │   │   ├── XlsCodec.kt
│       │   │   │   └── XlsxCodec.kt
│       │   │   ├── model/SpreadsheetModels.kt
│       │   │   └── ui/
│       │   │       ├── MainViewModel.kt
│       │   │       ├── MiniExcelApp.kt
│       │   │       └── theme/Theme.kt
│       │   └── res/values/
│       └── test/java/com/miniexcel/app/data/
├── .github/workflows/build.yml
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Build locally

1. Install Android Studio, Android SDK Platform 36, JDK 17, and Gradle 8.13.
2. Open this folder in Android Studio and configure it to use Gradle 8.13.
3. Run the `app` configuration on an Android 8.0+ device or emulator.
4. Run unit tests with `gradle :app:testDebugUnitTest`.
5. Build APKs with `gradle :app:assembleDebug :app:assembleRelease`.

The project uses Android Gradle Plugin 8.11.1 with Gradle 8.13 and Kotlin 2.2.20. On a clean machine, Gradle downloads the build dependencies once; the installed app does not need a network connection.

## Build on GitHub

1. Create an empty GitHub repository.
2. Upload the contents of this folder to the repository root (the `app/` and `.github/` folders must be at the root).
3. Push to any branch, open a pull request, or run **Actions → Android APK → Run workflow**.
4. Open the completed workflow run and download the `em-excel-apks-...` artifact. It contains the debug and release APKs.

The workflow installs JDK 17 and Android SDK 36, configures Gradle dependency caching, runs unit tests, builds both APK variants, and publishes them as a GitHub Actions artifact. The release APK is not signed with a private production signing key; configure your own signing credentials before publishing to an app store.

## Format and compatibility notes

- **XLSX:** The app reads common cell values, shared strings, sheet names, bold, and RGB fill colors. It writes normal worksheet data and the same basic formatting, and keeps unrelated OOXML ZIP parts where possible. It does not calculate formulas. Complex Excel features (charts, pivot tables, macros, advanced number formats, merged-cell editing, external links, and data validation) are outside the editor's scope and may not survive an edit/save round trip even when their package parts remain in the ZIP.
- **XLS:** The legacy `.xls` reader/writer uses Apache POI HSSF workbook/cell APIs. Because `.xls` is a legacy format, Excel's 65,536-row and 256-column limits apply. Fill colors are mapped to the closest color in the legacy workbook palette. Apache POI's broader API includes desktop AWT references that Android does not provide; this app keeps to HSSF cell I/O paths, but `.xls` behavior must still be verified on the target Android devices before a production rollout.
- **Editing limits:** The lightweight editor reads at most 100,000 rows and 256 columns per sheet and rejects source files larger than 50 MB or expanded XLSX packages larger than 120 MB.
- **CSV:** CSV has one sheet and cannot store formatting. Values are stored as UTF-8 with proper quoting; editing a CSV does not support worksheet tabs or style persistence.
- **Global search:** Android does not grant apps permission to silently enumerate arbitrary local storage. Search is limited to previously opened files and documents the user explicitly chooses for indexing. If access to a moved/deleted document is revoked, the app skips that file.
- **Save safety:** SAF document providers differ. eM Excel stages and validates data and keeps a private backup before overwriting an existing accessible file. This reduces risk, but no third-party SAF provider can guarantee an atomic replace operation; keep independent backups of important workbooks.
- **File size:** Workbooks are loaded into memory for editing. Very large files may exceed available memory on low-end devices; the app is intended for lightweight spreadsheets.

## Privacy

No account, analytics, advertising SDK, cloud sync, or internet permission is included. Indexed file URIs and names are stored locally in app-private preferences. A pre-save recovery copy, when created, is stored in the app's private files directory and is not uploaded anywhere.

## License

The eM Excel application source is provided under the MIT License. Apache POI retains its Apache License 2.0 terms; see the Apache POI project for its license and notices.


## Product direction

eM Excel is being redesigned around the mobile Microsoft Excel experience associated with version 16.0.13628.20214. This is an independent implementation, not Microsoft software and not a binary copy of Excel. The current pass applies the eM Excel identity and a Microsoft-Excel-inspired green workspace shell while retaining the existing local workbook engine and search workflow.
