# Keep HSSF model classes: selected POI code paths use class-name lookups.
-keep class org.apache.poi.hssf.** { *; }
-keep class org.apache.poi.ss.** { *; }
-keep class org.apache.poi.util.** { *; }

# Android does not ship desktop AWT/Swing APIs; this app uses HSSF cell I/O only.
-dontwarn java.awt.**
-dontwarn javax.swing.**
-dontwarn org.apache.poi.**
-dontwarn org.apache.xmlbeans.**
-dontwarn org.apache.logging.log4j.**
-dontwarn org.apache.commons.**
-dontwarn com.zaxxer.**

-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
