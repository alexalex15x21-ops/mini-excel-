package com.miniexcel.app.data

import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.model.WorkbookModel

/** RFC-4180 style CSV reader/writer with UTF-8 and escaped quotes/newlines. */
object CsvCodec {
    fun read(bytes: ByteArray, displayName: String): WorkbookModel {
        val text = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
        val records = parseRecords(text)
        val cells = LinkedHashMap<CellKey, CellContent>()
        var maxColumn = 0
        records.forEachIndexed { rowIndex, values ->
            values.forEachIndexed { columnIndex, value ->
                if (value.isNotEmpty()) cells[CellKey(rowIndex, columnIndex)] = CellContent(value)
                maxColumn = maxOf(maxColumn, columnIndex + 1)
            }
        }
        val rowCount = maxOf(30, records.size)
        return WorkbookModel(
            displayName = displayName,
            format = SpreadsheetFormat.CSV,
            sheets = listOf(
                SheetModel(
                    name = "Sheet1",
                    cells = cells,
                    rowCount = rowCount,
                    columnCount = maxOf(16, maxColumn)
                )
            )
        )
    }

    fun write(workbook: WorkbookModel): ByteArray {
        val sheet = workbook.sheets.firstOrNull() ?: SheetModel("Sheet1")
        val lastRow = sheet.cells.keys.maxOfOrNull { it.row } ?: -1
        val lastColumn = sheet.cells.keys.maxOfOrNull { it.column } ?: -1
        if (lastRow < 0 || lastColumn < 0) return byteArrayOf()

        val out = StringBuilder()
        for (row in 0..lastRow) {
            if (row > 0) out.append('\n')
            for (column in 0..lastColumn) {
                if (column > 0) out.append(',')
                val value = sheet.cells[CellKey(row, column)]?.value.orEmpty()
                out.append(escape(value))
            }
        }
        return out.toString().toByteArray(Charsets.UTF_8)
    }

    private fun escape(value: String): String {
        return if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"${value.replace("\"", "\"\"")}\""
        } else value
    }

    private fun parseRecords(input: String): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val field = StringBuilder()
        var quoted = false
        var index = 0

        while (index < input.length) {
            val character = input[index]
            when {
                quoted && character == '"' && index + 1 < input.length && input[index + 1] == '"' -> {
                    field.append('"')
                    index++
                }
                character == '"' && !quoted && field.isEmpty() -> quoted = true
                character == '"' && quoted -> quoted = false
                character == ',' && !quoted -> {
                    row.add(field.toString())
                    field.setLength(0)
                }
                (character == '\n' || character == '\r') && !quoted -> {
                    row.add(field.toString())
                    field.setLength(0)
                    rows.add(row)
                    row = ArrayList()
                    if (character == '\r' && index + 1 < input.length && input[index + 1] == '\n') index++
                }
                else -> field.append(character)
            }
            index++
        }

        if (field.isNotEmpty() || row.isNotEmpty() || (input.isNotEmpty() && input.last() == ',')) {
            row.add(field.toString())
            rows.add(row)
        }
        return rows
    }
}
