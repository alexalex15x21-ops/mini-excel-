package com.miniexcel.app.data

import android.content.Context
import com.miniexcel.app.model.IndexedFile
import org.json.JSONArray
import org.json.JSONObject

/** Stores only SAF URIs explicitly selected by the user, never crawls device storage. */
class LocalFileIndex(context: Context) {
    private val preferences = context.getSharedPreferences("mini_excel_local_index", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): List<IndexedFile> {
        val array = runCatching { JSONArray(preferences.getString(KEY_FILES, "[]")) }.getOrNull() ?: JSONArray()
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val uri = item.optString("uri").takeIf { it.isNotBlank() } ?: continue
                val name = item.optString("name").ifBlank { "Spreadsheet" }
                add(IndexedFile(uri, name))
            }
        }
    }

    @Synchronized
    fun add(file: IndexedFile) {
        val merged = all().associateBy { it.uri }.toMutableMap()
        merged[file.uri] = file
        persist(merged.values.sortedBy { it.name.lowercase() })
    }

    @Synchronized
    fun remove(uri: String) {
        persist(all().filterNot { it.uri == uri })
    }

    private fun persist(files: List<IndexedFile>) {
        val array = JSONArray()
        files.forEach { file ->
            array.put(JSONObject().put("uri", file.uri).put("name", file.name))
        }
        preferences.edit().putString(KEY_FILES, array.toString()).apply()
    }

    private companion object {
        const val KEY_FILES = "indexed_uris"
    }
}
