package com.miniexcel.app.data

import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.model.WorkbookModel
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

/**
 * Small Android-friendly OOXML codec for normal worksheet data.
 * It does not execute formulas; cached formula values are shown as stored values.
 * Unrelated ZIP package parts are carried forward when a workbook is saved.
 */
object XlsxCodec {
    private const val MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
    private const val MAX_UNCOMPRESSED_BYTES = 120L * 1024L * 1024L
    private const val MAX_PACKAGE_ENTRIES = 100_000

    fun read(bytes: ByteArray, displayName: String): WorkbookModel {
        val parts = unzip(bytes)
        val workbookBytes = parts["xl/workbook.xml"] ?: error("Invalid XLSX: workbook.xml is missing")
        val workbookDoc = parseXml(workbookBytes)
        val relationshipDoc = parts["xl/_rels/workbook.xml.rels"]?.let(::parseXml)
        val relationships = relationshipDoc?.let(::readRelationships).orEmpty()
        val sharedStrings = parts["xl/sharedStrings.xml"]?.let(::readSharedStrings).orEmpty()
        val styles = parts["xl/styles.xml"]?.let(::readStyles).orEmpty()

        val sheetNodes = workbookDoc.getElementsByTagNameNS("*", "sheet")
        val sheets = ArrayList<SheetModel>()
        for (index in 0 until sheetNodes.length) {
            val sheetElement = sheetNodes.item(index) as? Element ?: continue
            val sheetName = sheetElement.getAttribute("name").ifBlank { "Sheet${index + 1}" }
            val relationId = sheetElement.getAttributeNS(REL_NS, "id")
                .ifBlank { sheetElement.getAttribute("r:id") }
            val target = relationships[relationId] ?: continue
            val partName = resolvePart("xl/workbook.xml", target)
            val sheetBytes = parts[partName] ?: continue
            val cells = readSheet(parseXml(sheetBytes), sharedStrings, styles)
            val maxRow = cells.keys.maxOfOrNull { it.row + 1 } ?: 0
            val maxColumn = cells.keys.maxOfOrNull { it.column + 1 } ?: 0
            sheets.add(
                SheetModel(
                    name = sheetName,
                    cells = cells,
                    rowCount = maxOf(30, maxRow),
                    columnCount = maxOf(16, maxColumn),
                    sourcePartName = partName,
                    relationshipId = relationId
                )
            )
        }
        if (sheets.isEmpty()) sheets.add(SheetModel("Sheet1"))
        return WorkbookModel(displayName, SpreadsheetFormat.XLSX, sheets, parts)
    }

    fun write(workbook: WorkbookModel): ByteArray {
        require(workbook.sheets.isNotEmpty()) { "A workbook must contain at least one sheet." }
        val parts = LinkedHashMap(workbook.packageParts)
        ensurePackage(parts)

        val existingIds = parts.keys.mapNotNull { name ->
            Regex("xl/worksheets/sheet(\\d+)\\.xml").matchEntire(name)?.groupValues?.get(1)?.toIntOrNull()
        }.toMutableSet()
        var nextPartNumber = (existingIds.maxOrNull() ?: 0) + 1
        val usedRelIds = HashSet<String>()
        val bindings = workbook.sheets.mapIndexed { index, sheet ->
            val partName = sheet.sourcePartName?.takeIf { parts.containsKey(it) }
                ?: run {
                    while (nextPartNumber in existingIds) nextPartNumber++
                    val number = nextPartNumber++
                    existingIds.add(number)
                    "xl/worksheets/sheet$number.xml"
                }
            val relationId = sheet.relationshipId?.takeIf { it.isNotBlank() && usedRelIds.add(it) }
                ?: run {
                    var candidate = "rId${index + 1}"
                    var suffix = index + 1
                    while (!usedRelIds.add(candidate)) {
                        suffix++
                        candidate = "rId$suffix"
                    }
                    candidate
                }
            SheetBinding(sheet, partName, relationId)
        }

        val retainedSheetParts = bindings.map { it.partName }.toSet()
        parts.keys.filter { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) && it !in retainedSheetParts }
            .forEach(parts::remove)

        val styleBuild = buildStyles(workbook.sheets)
        parts["xl/styles.xml"] = styleBuild.xml.toByteArray(Charsets.UTF_8)
        bindings.forEach { binding ->
            parts[binding.partName] = writeSheet(binding.sheet, styleBuild.styleIds).toByteArray(Charsets.UTF_8)
        }

        val workbookDoc = parseXml(parts.getValue("xl/workbook.xml"))
        val root = workbookDoc.documentElement
        root.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:r", REL_NS)
        val originalSheetsElement = directChildren(root, "sheets").firstOrNull()
        val originalNextSibling = originalSheetsElement?.nextSibling
        originalSheetsElement?.let(root::removeChild)
        val sheetsElement = workbookDoc.createElementNS(MAIN_NS, "sheets")
        bindings.forEachIndexed { index, binding ->
            val sheetElement = workbookDoc.createElementNS(MAIN_NS, "sheet")
            sheetElement.setAttribute("name", binding.sheet.name.take(31).ifBlank { "Sheet${index + 1}" })
            sheetElement.setAttribute("sheetId", (index + 1).toString())
            sheetElement.setAttributeNS(REL_NS, "r:id", binding.relationshipId)
            sheetsElement.appendChild(sheetElement)
        }
        if (originalNextSibling != null) {
            root.insertBefore(sheetsElement, originalNextSibling)
        } else {
            val schemaSuccessor = listOf("functionGroups", "externalReferences", "definedNames", "calcPr", "oleSize", "customWorkbookViews", "pivotCaches", "smartTagPr", "smartTagTypes", "webPublishing", "fileRecoveryPr", "webPublishObjects", "extLst")
                .asSequence()
                .mapNotNull { name -> directChildren(root, name).firstOrNull() }
                .firstOrNull()
            if (schemaSuccessor != null) root.insertBefore(sheetsElement, schemaSuccessor) else root.appendChild(sheetsElement)
        }
        parts["xl/workbook.xml"] = serialize(workbookDoc)

        val relsDoc = parseXml(parts.getValue("xl/_rels/workbook.xml.rels"))
        val relsRoot = relsDoc.documentElement
        directChildren(relsRoot, "Relationship")
            .filter { it.getAttribute("Type").endsWith("/worksheet") }
            .forEach(relsRoot::removeChild)
        bindings.forEach { binding ->
            val rel = relsDoc.createElementNS(PKG_REL_NS, "Relationship")
            rel.setAttribute("Id", binding.relationshipId)
            rel.setAttribute("Type", "$REL_NS/worksheet")
            rel.setAttribute("Target", binding.partName.removePrefix("xl/"))
            relsRoot.appendChild(rel)
        }
        parts["xl/_rels/workbook.xml.rels"] = serialize(relsDoc)

        val contentDoc = parseXml(parts.getValue("[Content_Types].xml"))
        val contentRoot = contentDoc.documentElement
        directChildren(contentRoot, "Override")
            .filter { it.getAttribute("PartName").startsWith("/xl/worksheets/") }
            .forEach(contentRoot::removeChild)
        bindings.forEach { binding ->
            val override = contentDoc.createElementNS(CONTENT_NS, "Override")
            override.setAttribute("PartName", "/${binding.partName}")
            override.setAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")
            contentRoot.appendChild(override)
        }
        ensureContentDefault(contentDoc, "rels", "application/vnd.openxmlformats-package.relationships+xml")
        ensureContentDefault(contentDoc, "xml", "application/xml")
        if (directChildren(contentRoot, "Override").none { it.getAttribute("PartName") == "/xl/styles.xml" }) {
            val styleOverride = contentDoc.createElementNS(CONTENT_NS, "Override")
            styleOverride.setAttribute("PartName", "/xl/styles.xml")
            styleOverride.setAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")
            contentRoot.appendChild(styleOverride)
        }
        parts["[Content_Types].xml"] = serialize(contentDoc)

        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zip ->
            parts.forEach { (name, data) ->
                if (name.startsWith("/") || name.contains("../")) return@forEach
                zip.putNextEntry(ZipEntry(name))
                zip.write(data)
                zip.closeEntry()
            }
        }
        return output.toByteArray()
    }

    private data class SheetBinding(val sheet: SheetModel, val partName: String, val relationshipId: String)
    private data class StyleKey(val bold: Boolean, val background: String?)
    private data class StyleBuild(val xml: String, val styleIds: Map<StyleKey, Int>)

    private fun ensurePackage(parts: MutableMap<String, ByteArray>) {
        if (parts.containsKey("xl/workbook.xml")) return
        parts["[Content_Types].xml"] = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="$CONTENT_NS">
              <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
              <Default Extension="xml" ContentType="application/xml"/>
              <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
              <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
            </Types>
        """.trimIndent().toByteArray()
        parts["_rels/.rels"] = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="$PKG_REL_NS">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
            </Relationships>
        """.trimIndent().toByteArray()
        parts["xl/workbook.xml"] = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="$MAIN_NS" xmlns:r="$REL_NS"><sheets/></workbook>
        """.trimIndent().toByteArray()
        parts["xl/_rels/workbook.xml.rels"] = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="$PKG_REL_NS"/>
        """.trimIndent().toByteArray()
    }

    private fun ensureContentDefault(document: Document, extension: String, contentType: String) {
        val root = document.documentElement
        val exists = directChildren(root, "Default").any { it.getAttribute("Extension") == extension }
        if (!exists) {
            val element = document.createElementNS(CONTENT_NS, "Default")
            element.setAttribute("Extension", extension)
            element.setAttribute("ContentType", contentType)
            root.appendChild(element)
        }
    }

    private fun readRelationships(document: Document): Map<String, String> {
        val result = HashMap<String, String>()
        val nodes = document.getElementsByTagNameNS("*", "Relationship")
        for (index in 0 until nodes.length) {
            val element = nodes.item(index) as? Element ?: continue
            result[element.getAttribute("Id")] = element.getAttribute("Target")
        }
        return result
    }

    private fun resolvePart(basePart: String, target: String): String {
        if (target.startsWith("/")) return target.removePrefix("/")
        val base = basePart.substringBeforeLast('/')
        val pieces = java.util.ArrayDeque<String>()
        ("$base/$target").split('/').forEach { piece ->
            when (piece) {
                "", "." -> Unit
                ".." -> if (pieces.isNotEmpty()) pieces.removeLast()
                else -> pieces.addLast(piece)
            }
        }
        return pieces.joinToString("/")
    }

    private fun readSharedStrings(bytes: ByteArray): List<String> {
        val doc = parseXml(bytes)
        val nodes = doc.getElementsByTagNameNS("*", "si")
        return (0 until nodes.length).map { index ->
            val item = nodes.item(index)
            descendantText(item, "t")
        }
    }

    private fun readStyles(bytes: ByteArray): List<StyleKey> {
        val doc = parseXml(bytes)
        val fontsContainer = firstElement(doc, "fonts")
        val fillsContainer = firstElement(doc, "fills")
        val xfsContainer = firstElement(doc, "cellXfs")
        val fonts = directChildren(fontsContainer, "font").map { font ->
            directChildren(font, "b").isNotEmpty()
        }
        val fills = directChildren(fillsContainer, "fill").map { fill ->
            val pattern = directChildren(fill, "patternFill").firstOrNull()
            val color = pattern?.let { directChildren(it, "fgColor").firstOrNull() }
            normalizeRgb(color?.getAttribute("rgb"))
        }
        return directChildren(xfsContainer, "xf").map { xf ->
            val fontIndex = xf.getAttribute("fontId").toIntOrNull() ?: 0
            val fillIndex = xf.getAttribute("fillId").toIntOrNull() ?: 0
            StyleKey(fonts.getOrNull(fontIndex) == true, fills.getOrNull(fillIndex))
        }
    }

    private fun readSheet(
        document: Document,
        sharedStrings: List<String>,
        styles: List<StyleKey>
    ): Map<CellKey, CellContent> {
        val result = LinkedHashMap<CellKey, CellContent>()
        val nodes = document.getElementsByTagNameNS("*", "c")
        for (index in 0 until nodes.length) {
            val cell = nodes.item(index) as? Element ?: continue
            val address = cell.getAttribute("r")
            val key = parseCellAddress(address) ?: continue
            val type = cell.getAttribute("t")
            val styleIndex = cell.getAttribute("s").toIntOrNull() ?: 0
            val rawValue = directChildren(cell, "v").firstOrNull()?.textContent.orEmpty()
            val value = when (type) {
                "s" -> sharedStrings.getOrNull(rawValue.toIntOrNull() ?: -1).orEmpty()
                "inlineStr" -> directChildren(cell, "is").firstOrNull()?.textContent.orEmpty()
                "b" -> if (rawValue == "1") "TRUE" else "FALSE"
                else -> rawValue
            }
            val style = styles.getOrNull(styleIndex) ?: StyleKey(false, null)
            if (value.isNotEmpty() || style.bold || style.background != null) {
                result[key] = CellContent(value, style.bold, style.background)
            }
        }
        return result
    }

    private fun buildStyles(sheets: List<SheetModel>): StyleBuild {
        val keys = linkedSetOf(StyleKey(false, null))
        sheets.flatMap { it.cells.values }.forEach { cell ->
            keys.add(StyleKey(cell.bold, normalizeRgb(cell.background)))
        }
        val colors = keys.mapNotNull { it.background }.distinct()
        val colorFillIds = colors.mapIndexed { index, color -> color to index + 2 }.toMap()
        val boldFontId = 1
        val styleIds = keys.mapIndexed { index, key -> key to index }.toMap()
        val fonts = buildString {
            append("<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>")
            append("<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>")
        }
        val fills = buildString {
            append("<fills count=\"${2 + colors.size}\"><fill><patternFill patternType=\"none\"/></fill>")
            append("<fill><patternFill patternType=\"gray125\"/></fill>")
            colors.forEach { color ->
                append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF${color.removePrefix("#")}\"/><bgColor indexed=\"64\"/></patternFill></fill>")
            }
            append("</fills>")
        }
        val xfs = buildString {
            append("<cellXfs count=\"${keys.size}\">")
            keys.forEach { key ->
                val fontId = if (key.bold) boldFontId else 0
                val fillId = key.background?.let { colorFillIds[it] } ?: 0
                append("<xf numFmtId=\"0\" fontId=\"$fontId\" fillId=\"$fillId\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>")
            }
            append("</cellXfs>")
        }
        val xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="$MAIN_NS">$fonts$fills<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>$xfs<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""
        return StyleBuild(xml, styleIds)
    }

    private fun writeSheet(sheet: SheetModel, styleIds: Map<StyleKey, Int>): String {
        val lastRow = maxOf(sheet.rowCount - 1, sheet.cells.keys.maxOfOrNull { it.row } ?: 0)
        val lastColumn = maxOf(sheet.columnCount - 1, sheet.cells.keys.maxOfOrNull { it.column } ?: 0)
        val dimension = "A1:${columnName(lastColumn)}${lastRow + 1}"
        val out = StringBuilder()
        out.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        out.append("<worksheet xmlns=\"$MAIN_NS\"><dimension ref=\"$dimension\"/><sheetViews><sheetView workbookViewId=\"0\"/></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><sheetData>")
        val cellsByRow = sheet.cells.entries
            .filter { it.key.row >= 0 && it.key.column >= 0 && (it.value.value.isNotEmpty() || it.value.bold || it.value.background != null) }
            .groupBy { it.key.row }
        val rowIndexes = cellsByRow.keys.sorted()
        rowIndexes.forEach { rowIndex ->
            out.append("<row r=\"${rowIndex + 1}\">")
            cellsByRow.getValue(rowIndex).sortedBy { it.key.column }.forEach { (key, content) ->
                val styleId = styleIds[StyleKey(content.bold, normalizeRgb(content.background))] ?: 0
                val ref = "${columnName(key.column)}${key.row + 1}"
                val value = content.value
                out.append("<c r=\"$ref\" s=\"$styleId\"")
                if (isNumeric(value)) {
                    out.append("><v>${xmlEscape(value)}</v></c>")
                } else {
                    out.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value)}</t></is></c>")
                }
            }
            out.append("</row>")
        }
        out.append("</sheetData></worksheet>")
        return out.toString()
    }

    private fun isNumeric(value: String): Boolean {
        if (value.isBlank() || value.startsWith("0") && value.length > 1 && value[1].isDigit()) return false
        return value.matches(Regex("[-+]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][-+]?\\d+)?"))
    }

    private fun parseCellAddress(address: String): CellKey? {
        val match = Regex("^([A-Za-z]+)([1-9][0-9]*)$").matchEntire(address) ?: return null
        var column = 0
        match.groupValues[1].uppercase(Locale.ROOT).forEach { char -> column = column * 26 + (char - 'A' + 1) }
        val row = match.groupValues[2].toIntOrNull() ?: return null
        val zeroColumn = column - 1
        val zeroRow = row - 1
        if (zeroRow !in 0..99_999 || zeroColumn !in 0..255) return null
        return CellKey(zeroRow, zeroColumn)
    }

    private fun columnName(zeroBased: Int): String {
        var value = zeroBased + 1
        val result = StringBuilder()
        while (value > 0) {
            val remainder = (value - 1) % 26
            result.insert(0, ('A'.code + remainder).toChar())
            value = (value - 1) / 26
        }
        return result.toString()
    }

    private fun normalizeRgb(value: String?): String? {
        val raw = value?.trim()?.removePrefix("#") ?: return null
        if (raw.isBlank()) return null
        val rgb = if (raw.length == 8) raw.takeLast(6) else raw
        return if (rgb.matches(Regex("[0-9A-Fa-f]{6}"))) "#${rgb.uppercase(Locale.ROOT)}" else null
    }

    private fun xmlEscape(value: String): String = value.filter { it == '\t' || it == '\n' || it == '\r' || it.code >= 0x20 }
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun unzip(bytes: ByteArray): MutableMap<String, ByteArray> {
        val parts = LinkedHashMap<String, ByteArray>()
        var totalUncompressed = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            val buffer = ByteArray(8 * 1024)
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val output = ByteArrayOutputStream()
                    while (true) {
                        val count = zip.read(buffer)
                        if (count < 0) break
                        totalUncompressed += count
                        require(totalUncompressed <= MAX_UNCOMPRESSED_BYTES) { "The expanded workbook is too large to open safely." }
                        output.write(buffer, 0, count)
                    }
                    parts[entry.name] = output.toByteArray()
                }
                zip.closeEntry()
                require(parts.size < MAX_PACKAGE_ENTRIES) { "The workbook contains too many package entries." }
                entry = zip.nextEntry
            }
        }
        return parts
    }

    private fun parseXml(bytes: ByteArray): Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            isExpandEntityReferences = false
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) { }
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") } catch (_: Exception) { }
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") } catch (_: Exception) { }
        }
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun serialize(document: Document): ByteArray {
        val transformer = TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.INDENT, "no")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
        }
        val output = ByteArrayOutputStream()
        transformer.transform(DOMSource(document), StreamResult(output))
        return output.toByteArray()
    }

    private fun firstElement(document: Document, localName: String): Element? =
        document.getElementsByTagNameNS("*", localName).item(0) as? Element

    private fun directChildren(node: Node?, localName: String): List<Element> {
        if (node == null) return emptyList()
        val result = ArrayList<Element>()
        val children = node.childNodes
        for (index in 0 until children.length) {
            val element = children.item(index) as? Element ?: continue
            val name = element.localName ?: element.nodeName.substringAfter(':')
            if (name == localName) result.add(element)
        }
        return result
    }

    private fun descendantText(node: Node, localName: String): String {
        val nodes = (node as? Element)?.getElementsByTagNameNS("*", localName) ?: return ""
        return buildString {
            for (index in 0 until nodes.length) append(nodes.item(index).textContent.orEmpty())
        }
    }
}
