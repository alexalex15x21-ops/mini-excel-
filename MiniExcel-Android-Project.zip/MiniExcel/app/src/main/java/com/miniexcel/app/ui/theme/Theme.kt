package com.miniexcel.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MiniExcelColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    secondary = Color(0xFF475569),
    background = Color(0xFFF7F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEFF2F8),
    outline = Color(0xFFD7DCE5),
    error = Color(0xFFB42318)
)

@Composable
fun MiniExcelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MiniExcelColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
