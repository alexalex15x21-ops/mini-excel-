package com.miniexcel.app.ui

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableRows
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.SearchResult
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import kotlinx.coroutines.launch

private val gridBorder = Color(0xFFE2E6EE)
private val headerBackground = Color(0xFFF0F3F8)
private val palette = listOf(
    "#FFF2CC" to "Yellow",
    "#E2F0D9" to "Green",
    "#DDEBF7" to "Blue",
    "#FCE4D6" to "Orange",
    "#E4DFEC" to "Purple",
    "#E7E6E6" to "Gray"
)

@Composable
fun MiniExcelApp(
    viewModel: MainViewModel,
    onOpenFile: () -> Unit,
    onIndexFiles: () -> Unit,
    onCreateFile: (String, SpreadsheetFormat) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showCreateDialog by rememberSaveable { mutableStateOf(false) }
    var showSearchDialog by rememberSaveable { mutableStateOf(false) }
    var showEditDialog by rememberSaveable { mutableStateOf(false) }
    var showSheetRename by rememberSaveable { mutableStateOf(false) }
    var showDeleteSheetConfirm by rememberSaveable { mutableStateOf(false) }
    var fillMenuExpanded by remember { mutableStateOf(false) }
    var sheetMenuExpanded by remember { mutableStateOf(false) }
    var editValue by remember { mutableStateOf("") }
    var createName by remember { mutableStateOf("New spreadsheet") }
    var createFormat by remember { mutableStateOf(SpreadsheetFormat.XLSX) }
    var searchText by remember { mutableStateOf("") }
    var renameText by remember { mutableStateOf("") }

    val opened = state.opened
    val workbook = opened?.workbook
    val currentSheet = workbook?.sheets?.getOrNull(state.activeSheetIndex)
    val selectedContent = currentSheet?.cells?.get(state.selectedCell) ?: CellContent()

    LaunchedEffect(state.selectedCell, state.activeSheetIndex, opened?.uri) {
        if (showEditDialog) editValue = selectedContent.value
    }

    Scaffold(
        containerColor = Color(0xFFF7F8FC),
        topBar = {
            Surface(shadowElevation = 2.dp, color = Color.White) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Mini Excel", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF172033))
                            Text(
                                text = opened?.displayName ?: "Offline spreadsheet editor",
                                fontSize = 11.sp,
                                color = Color(0xFF697386),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = onOpenFile) { Icon(Icons.Default.FileOpen, contentDescription = "Open file") }
                        IconButton(onClick = { showCreateDialog = true }) { Icon(Icons.Default.AddBox, contentDescription = "New spreadsheet") }
                        IconButton(onClick = { searchText = ""; showSearchDialog = true }) { Icon(Icons.Default.Search, contentDescription = "Global search") }
                        IconButton(onClick = viewModel::save, enabled = opened != null && !state.isBusy) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = if (state.dirty) MaterialTheme.colorScheme.primary else Color(0xFF687386))
                        }
                    }
                    if (state.isBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (state.message != null) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFEAF1FF)).clickable { viewModel.clearMessage() }.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(state.message.orEmpty(), modifier = Modifier.weight(1f), fontSize = 12.sp, color = Color(0xFF244B91))
                    Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp), tint = Color(0xFF244B91))
                }
            }
            if (opened == null || currentSheet == null) {
                EmptyWorkspace(
                    indexedCount = state.indexedCount,
                    onOpenFile = onOpenFile,
                    onCreate = { showCreateDialog = true },
                    onIndexFiles = onIndexFiles
                )
            } else {
                EditorToolbar(
                    dirty = state.dirty,
                    selectedBold = selectedContent.bold,
                    isCsv = workbook.format == SpreadsheetFormat.CSV,
                    onToggleBold = viewModel::toggleBold,
                    onFillClick = { fillMenuExpanded = true },
                    onInsertRow = viewModel::insertRow,
                    onDeleteRow = viewModel::deleteRow,
                    onInsertColumn = viewModel::insertColumn,
                    onDeleteColumn = viewModel::deleteColumn,
                    onAddSheet = viewModel::addSheet,
                    fillMenuExpanded = fillMenuExpanded,
                    onFillMenuDismiss = { fillMenuExpanded = false },
                    onSetFill = { viewModel.setBackground(it); fillMenuExpanded = false }
                )
                SheetTabs(
                    sheets = workbook.sheets,
                    activeIndex = state.activeSheetIndex,
                    isCsv = workbook.format == SpreadsheetFormat.CSV,
                    onSelect = viewModel::selectSheet,
                    onAdd = viewModel::addSheet,
                    onMore = { sheetMenuExpanded = true }
                )
                SpreadsheetGrid(
                    sheet = currentSheet,
                    selectedCell = state.selectedCell,
                    onSelectCell = { key ->
                        viewModel.selectCell(key)
                        editValue = currentSheet.cells[key]?.value.orEmpty()
                        showEditDialog = true
                    }
                )
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${columnLabel(state.selectedCell.column)}${state.selectedCell.row + 1}",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(selectedContent.value.ifEmpty { "Empty cell" }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color(0xFF647084))
                    Spacer(Modifier.weight(1f))
                    if (state.dirty) Text("Unsaved", color = Color(0xFFB45309), fontSize = 11.sp)
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create spreadsheet") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = createName,
                        onValueChange = { createName = it },
                        label = { Text("File name") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                    )
                    Text("File format", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = createFormat == SpreadsheetFormat.XLSX, onClick = { createFormat = SpreadsheetFormat.XLSX })
                        Text("Excel (.xlsx)", modifier = Modifier.clickable { createFormat = SpreadsheetFormat.XLSX }, fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = createFormat == SpreadsheetFormat.CSV, onClick = { createFormat = SpreadsheetFormat.CSV })
                        Text("CSV (.csv)", modifier = Modifier.clickable { createFormat = SpreadsheetFormat.CSV }, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val name = createName.trim().ifBlank { "New spreadsheet" }
                    showCreateDialog = false
                    onCreateFile(name, createFormat)
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("Search all indexed files") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        label = { Text("Text to find") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { searchText = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                        }
                    )
                    Text("Search includes files opened in Mini Excel and files explicitly added to the local index.", fontSize = 11.sp, color = Color(0xFF687386))
                    Text("Indexed files: ${state.indexedCount}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = {
                Button(onClick = {
                    showSearchDialog = false
                    viewModel.search(searchText)
                }) { Text("Search") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showSearchDialog = false
                    onIndexFiles()
                }) { Text("Add files to index") }
            }
        )
    }

    if (state.showSearchResults) {
        SearchResultsDialog(
            query = state.searchQuery,
            results = state.searchResults,
            busy = state.isBusy,
            onDismiss = viewModel::dismissSearchResults,
            onSelect = viewModel::openSearchResult
        )
    }

    if (showEditDialog && currentSheet != null) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit ${columnLabel(state.selectedCell.column)}${state.selectedCell.row + 1}") },
            text = {
                OutlinedTextField(
                    value = editValue,
                    onValueChange = { editValue = it },
                    label = { Text("Cell value") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, capitalization = KeyboardCapitalization.Sentences)
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.editCell(editValue); showEditDialog = false }) { Text("Apply") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { editValue = ""; viewModel.editCell(""); showEditDialog = false }) { Text("Clear") }
                    TextButton(onClick = { showEditDialog = false }) { Text("Cancel") }
                }
            }
        )
    }

    if (sheetMenuExpanded && currentSheet != null && workbook != null) {
        AlertDialog(
            onDismissRequest = { sheetMenuExpanded = false },
            title = { Text(currentSheet.name) },
            text = { Text("Manage the active worksheet.") },
            confirmButton = {
                TextButton(onClick = {
                    renameText = currentSheet.name
                    showSheetRename = true
                    sheetMenuExpanded = false
                }) { Text("Rename") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showDeleteSheetConfirm = true; sheetMenuExpanded = false }, enabled = workbook.sheets.size > 1) { Text("Delete") }
                    TextButton(onClick = { sheetMenuExpanded = false }) { Text("Close") }
                }
            }
        )
    }

    if (showSheetRename) {
        AlertDialog(
            onDismissRequest = { showSheetRename = false },
            title = { Text("Rename sheet") },
            text = {
                OutlinedTextField(value = renameText, onValueChange = { renameText = it }, label = { Text("Sheet name") }, singleLine = true)
            },
            confirmButton = {
                Button(onClick = { viewModel.renameActiveSheet(renameText); showSheetRename = false }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { showSheetRename = false }) { Text("Cancel") } }
        )
    }

    if (showDeleteSheetConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteSheetConfirm = false },
            title = { Text("Delete sheet?") },
            text = { Text("This removes the active sheet from the workbook. Save to keep the change.") },
            confirmButton = {
                Button(onClick = { viewModel.deleteActiveSheet(); showDeleteSheetConfirm = false }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { showDeleteSheetConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun EmptyWorkspace(
    indexedCount: Int,
    onOpenFile: () -> Unit,
    onCreate: () -> Unit,
    onIndexFiles: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFFE8EFFF), modifier = Modifier.size(84.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.TableRows, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(42.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Your offline spreadsheet workspace", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Color(0xFF172033))
        Spacer(Modifier.height(8.dp))
        Text(
            "Open an Excel or CSV file, or create a new sheet. Your documents stay on this device.",
            color = Color(0xFF687386), fontSize = 13.sp, lineHeight = 19.sp
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onOpenFile, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FileOpen, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Open spreadsheet")
        }
        FilledTonalButton(onClick = onCreate, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Create new file")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onIndexFiles, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add files to global search ($indexedCount)")
        }
        Spacer(Modifier.height(20.dp))
        Text("No internet permission • Local SAF file access • No cloud sync", fontSize = 10.sp, color = Color(0xFF8892A2))
    }
}

@Composable
private fun EditorToolbar(
    dirty: Boolean,
    selectedBold: Boolean,
    isCsv: Boolean,
    onToggleBold: () -> Unit,
    onFillClick: () -> Unit,
    onInsertRow: () -> Unit,
    onDeleteRow: () -> Unit,
    onInsertColumn: () -> Unit,
    onDeleteColumn: () -> Unit,
    onAddSheet: () -> Unit,
    fillMenuExpanded: Boolean,
    onFillMenuDismiss: () -> Unit,
    onSetFill: (String?) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color.White).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AssistChip(onClick = onToggleBold, enabled = !isCsv, label = { Text("Bold", fontSize = 12.sp) }, leadingIcon = {
            Icon(Icons.Default.FormatBold, contentDescription = null, tint = if (selectedBold) MaterialTheme.colorScheme.primary else Color(0xFF475569))
        })
        Box {
            AssistChip(onClick = onFillClick, enabled = !isCsv, label = { Text("Fill", fontSize = 12.sp) }, leadingIcon = { Icon(Icons.Default.FormatColorFill, contentDescription = null) })
            DropdownMenu(expanded = fillMenuExpanded, onDismissRequest = onFillMenuDismiss) {
                DropdownMenuItem(text = { Text("No fill") }, onClick = { onSetFill(null) })
                palette.forEach { (hex, name) ->
                    DropdownMenuItem(
                        text = { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(18.dp).background(Color(AndroidColor.parseColor(hex)), RoundedCornerShape(4.dp))); Spacer(Modifier.width(8.dp)); Text(name) } },
                        onClick = { onSetFill(hex) }
                    )
                }
            }
        }
        Divider(modifier = Modifier.height(26.dp).width(1.dp))
        SmallToolButton("+ Row", onClick = onInsertRow)
        SmallToolButton("− Row", onClick = onDeleteRow)
        SmallToolButton("+ Column", onClick = onInsertColumn)
        SmallToolButton("− Column", onClick = onDeleteColumn)
        if (!isCsv) SmallToolButton("+ Sheet", onClick = onAddSheet)
        if (isCsv) Text("CSV: text only", color = Color(0xFF7C8798), fontSize = 10.sp)
        if (dirty) Text("●", color = Color(0xFFD97706), fontSize = 13.sp)
    }
}

@Composable
private fun SmallToolButton(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
        Text(label, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun SheetTabs(
    sheets: List<SheetModel>,
    activeIndex: Int,
    isCsv: Boolean,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    onMore: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFFFBFCFE)).padding(start = 8.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            sheets.forEachIndexed { index, sheet ->
                FilterChip(
                    selected = activeIndex == index,
                    onClick = { onSelect(index) },
                    label = { Text(sheet.name, maxLines = 1, fontSize = 12.sp) }
                )
            }
        }
        if (!isCsv) {
            IconButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Add sheet") }
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, contentDescription = "Sheet options") }
        }
    }
}

@Composable
private fun SpreadsheetGrid(
    sheet: SheetModel,
    selectedCell: CellKey,
    onSelectCell: (CellKey) -> Unit
) {
    val horizontalState = rememberScrollState()
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    val rowNumberWidth = 48.dp
    val cellWidth = 112.dp
    val cellHeight = 42.dp
    val columnCount = maxOf(sheet.columnCount, sheet.cells.keys.maxOfOrNull { it.column + 1 } ?: 0, 16).coerceAtMost(256)
    val rowCount = maxOf(sheet.rowCount, sheet.cells.keys.maxOfOrNull { it.row + 1 } ?: 0, 30).coerceAtMost(100_000)
    val horizontalTarget = with(density) { (cellWidth * selectedCell.column).toPx().roundToInt() }

    LaunchedEffect(selectedCell.row, rowCount) {
        if (selectedCell.row in 0 until rowCount) listState.animateScrollToItem(selectedCell.row)
    }
    LaunchedEffect(selectedCell.column, horizontalTarget) {
        horizontalState.animateScrollTo(horizontalTarget.coerceAtLeast(0))
    }

    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Row(modifier = Modifier.fillMaxWidth().height(cellHeight), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.width(rowNumberWidth).fillMaxHeight().background(headerBackground).border(0.5.dp, gridBorder),
                contentAlignment = Alignment.Center
            ) { Text("#", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF596477)) }
            Row(modifier = Modifier.horizontalScroll(horizontalState)) {
                repeat(columnCount) { column ->
                    Box(
                        modifier = Modifier.width(cellWidth).height(cellHeight).background(headerBackground).border(0.5.dp, gridBorder),
                        contentAlignment = Alignment.Center
                    ) { Text(columnLabel(column), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF596477)) }
                }
            }
        }
        Divider(color = gridBorder, thickness = 1.dp)
        LazyColumn(modifier = Modifier.fillMaxSize(), state = listState) {
            itemsIndexed((0 until rowCount).toList(), key = { _, row -> row }) { _, rowIndex ->
                Row(modifier = Modifier.fillMaxWidth().height(cellHeight)) {
                    Box(
                        modifier = Modifier.width(rowNumberWidth).fillMaxHeight().background(headerBackground).border(0.5.dp, gridBorder),
                        contentAlignment = Alignment.Center
                    ) { Text((rowIndex + 1).toString(), fontSize = 11.sp, color = Color(0xFF667085)) }
                    Row(modifier = Modifier.horizontalScroll(horizontalState)) {
                        repeat(columnCount) { column ->
                            val key = CellKey(rowIndex, column)
                            val content = sheet.cells[key] ?: CellContent()
                            val backgroundColor = content.background?.let {
                                runCatching { Color(AndroidColor.parseColor(it)) }.getOrNull()
                            } ?: Color.White
                            val selected = key == selectedCell
                            Box(
                                modifier = Modifier
                                    .width(cellWidth)
                                    .height(cellHeight)
                                    .background(backgroundColor)
                                    .border(if (selected) 2.dp else 0.5.dp, if (selected) Color(0xFF2563EB) else gridBorder)
                                    .clickable { onSelectCell(key) }
                                    .padding(horizontal = 7.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = content.value,
                                    fontSize = 12.sp,
                                    fontWeight = if (content.bold) FontWeight.Bold else FontWeight.Normal,
                                    color = Color(0xFF182230),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultsDialog(
    query: String,
    results: List<SearchResult>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSelect: (SearchResult) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Search results")
                Text("\"$query\" • ${results.size} match(es)", fontSize = 11.sp, color = Color(0xFF647084), fontWeight = FontWeight.Normal)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (busy) {
                    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                    }
                } else if (results.isEmpty()) {
                    Text("No matching cells were found. Add files to the index and try again.", fontSize = 13.sp, color = Color(0xFF687386))
                } else {
                    LazyColumn(modifier = Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        itemsIndexed(results, key = { index, result -> "${result.uri}_${result.sheetName}_${result.rowNumber}_${result.columnNumber}_$index" }) { _, result ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { onSelect(result) },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F9FC))
                            ) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(result.fileName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF172033), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${result.sheetName} • Row ${result.rowNumber} • ${columnLabel(result.columnNumber - 1)}", fontSize = 11.sp, color = Color(0xFF647084))
                                    Text(result.preview, fontSize = 12.sp, color = Color(0xFF344054), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

private fun columnLabel(zeroBased: Int): String {
    var value = zeroBased + 1
    val result = StringBuilder()
    while (value > 0) {
        val remainder = (value - 1) % 26
        result.insert(0, ('A'.code + remainder).toChar())
        value = (value - 1) / 26
    }
    return result.toString()
}
