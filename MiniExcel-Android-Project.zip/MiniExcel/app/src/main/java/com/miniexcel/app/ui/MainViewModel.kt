package com.miniexcel.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.miniexcel.app.data.LocalFileIndex
import com.miniexcel.app.data.SpreadsheetRepository
import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.IndexedFile
import com.miniexcel.app.model.OpenedWorkbook
import com.miniexcel.app.model.SearchResult
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

 data class AppUiState(
    val opened: OpenedWorkbook? = null,
    val activeSheetIndex: Int = 0,
    val selectedCell: CellKey = CellKey(0, 0),
    val dirty: Boolean = false,
    val isBusy: Boolean = false,
    val message: String? = null,
    val searchResults: List<SearchResult> = emptyList(),
    val searchQuery: String = "",
    val showSearchResults: Boolean = false,
    val indexedCount: Int = 0
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SpreadsheetRepository(application)
    private val fileIndex = LocalFileIndex(application)
    private val _state = MutableStateFlow(AppUiState(indexedCount = fileIndex.all().size))
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    fun open(uri: Uri) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, message = null, showSearchResults = false)
            runCatching {
                withContext(Dispatchers.IO) {
                    val opened = repository.read(uri)
                    fileIndex.add(repository.indexEntry(uri))
                    opened
                }
            }.onSuccess { opened ->
                _state.value = AppUiState(
                    opened = opened,
                    indexedCount = fileIndex.all().size,
                    message = "Opened ${opened.displayName}"
                )
            }.onFailure { error ->
                _state.value = _state.value.copy(isBusy = false, message = error.message ?: "Could not open this file.")
            }
        }
    }

    fun indexFiles(uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri -> runCatching { repository.indexEntry(uri) }.getOrNull() }
            }
            added.forEach(fileIndex::add)
            _state.value = _state.value.copy(
                indexedCount = fileIndex.all().size,
                message = if (added.isEmpty()) "No files were added to the search index." else "Added ${added.size} file(s) to global search."
            )
        }
    }

    fun create(uri: Uri, name: String, format: SpreadsheetFormat) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, message = null)
            runCatching {
                withContext(Dispatchers.IO) { repository.createBlank(uri, name, format) }
            }.onSuccess { opened ->
                fileIndex.add(IndexedFile(uri.toString(), opened.displayName))
                _state.value = AppUiState(
                    opened = opened,
                    indexedCount = fileIndex.all().size,
                    message = "Created ${opened.displayName}"
                )
            }.onFailure { error ->
                _state.value = _state.value.copy(isBusy = false, message = error.message ?: "Could not create the file.")
            }
        }
    }

    fun save() {
        val opened = _state.value.opened ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, message = null)
            runCatching {
                withContext(Dispatchers.IO) { repository.save(opened) }
            }.onSuccess { saved ->
                _state.value = _state.value.copy(opened = saved, dirty = false, isBusy = false, message = "Saved ${saved.displayName}")
            }.onFailure { error ->
                _state.value = _state.value.copy(isBusy = false, message = error.message ?: "Save failed.")
            }
        }
    }

    fun selectSheet(index: Int) {
        val sheets = _state.value.opened?.workbook?.sheets ?: return
        if (index in sheets.indices) _state.value = _state.value.copy(activeSheetIndex = index, selectedCell = CellKey(0, 0))
    }

    fun selectCell(key: CellKey) {
        val format = _state.value.opened?.workbook?.format
        val lastRow = if (format == SpreadsheetFormat.XLS) 65_535 else 99_999
        val bounded = CellKey(key.row.coerceIn(0, lastRow), key.column.coerceIn(0, 255))
        _state.value = _state.value.copy(selectedCell = bounded)
    }

    fun editCell(value: String) {
        updateActiveSheet { sheet, selected ->
            val cells = sheet.cells.toMutableMap()
            val old = cells[selected] ?: CellContent()
            val updated = old.copy(value = value)
            if (updated.value.isEmpty() && !updated.bold && updated.background == null) cells.remove(selected)
            else cells[selected] = updated
            sheet.copy(cells = cells, rowCount = maxOf(sheet.rowCount, selected.row + 1), columnCount = maxOf(sheet.columnCount, selected.column + 1))
        }
    }

    fun toggleBold() {
        updateSelectedCell { it.copy(bold = !it.bold) }
    }

    fun setBackground(color: String?) {
        updateSelectedCell { it.copy(background = color) }
    }

    fun addSheet() {
        val opened = _state.value.opened ?: return
        if (opened.workbook.format == SpreadsheetFormat.CSV) {
            showMessage("CSV files support one sheet. Save as XLSX to use multiple sheets.")
            return
        }
        val current = opened.workbook
        val baseName = "Sheet"
        var suffix = current.sheets.size + 1
        var name = "$baseName$suffix"
        while (current.sheets.any { it.name.equals(name, ignoreCase = true) }) {
            suffix++
            name = "$baseName$suffix"
        }
        val next = current.copy(sheets = current.sheets + SheetModel(name))
        replaceWorkbook(next, activeSheet = next.sheets.lastIndex, selected = CellKey(0, 0))
    }

    fun renameActiveSheet(name: String) {
        val clean = name.trim().take(31)
        if (clean.isEmpty()) return
        val opened = _state.value.opened ?: return
        val index = _state.value.activeSheetIndex
        if (opened.workbook.sheets.withIndex().any { it.index != index && it.value.name.equals(clean, true) }) {
            showMessage("A sheet with this name already exists.")
            return
        }
        val sheets = opened.workbook.sheets.toMutableList()
        sheets[index] = sheets[index].copy(name = clean)
        replaceWorkbook(opened.workbook.copy(sheets = sheets))
    }

    fun deleteActiveSheet() {
        val opened = _state.value.opened ?: return
        if (opened.workbook.sheets.size <= 1) {
            showMessage("A workbook must keep at least one sheet.")
            return
        }
        val index = _state.value.activeSheetIndex
        val sheets = opened.workbook.sheets.toMutableList().also { it.removeAt(index) }
        replaceWorkbook(opened.workbook.copy(sheets = sheets), activeSheet = index.coerceAtMost(sheets.lastIndex))
    }

    fun insertRow() {
        val format = _state.value.opened?.workbook?.format
        val maximumRows = if (format == SpreadsheetFormat.XLS) 65_536 else 100_000
        val active = _state.value.opened?.workbook?.sheets?.getOrNull(_state.value.activeSheetIndex)
        if (active != null && active.rowCount >= maximumRows) {
            showMessage("This file format supports at most $maximumRows rows per sheet.")
            return
        }
        updateActiveSheet { sheet, selected ->
            val at = (selected.row + 1).coerceAtMost(maximumRows - 1)
            val cells = LinkedHashMap<CellKey, CellContent>()
            sheet.cells.forEach { (key, value) ->
                val row = if (key.row >= at) key.row + 1 else key.row
                if (row < maximumRows) cells[CellKey(row, key.column)] = value
            }
            sheet.copy(cells = cells, rowCount = (sheet.rowCount + 1).coerceAtMost(maximumRows))
        }
    }

    fun deleteRow() {
        updateActiveSheet { sheet, selected ->
            val cells = LinkedHashMap<CellKey, CellContent>()
            sheet.cells.forEach { (key, value) ->
                when {
                    key.row < selected.row -> cells[key] = value
                    key.row > selected.row -> cells[CellKey(key.row - 1, key.column)] = value
                }
            }
            sheet.copy(cells = cells, rowCount = (sheet.rowCount - 1).coerceAtLeast(1))
        }
        _state.value = _state.value.copy(selectedCell = _state.value.selectedCell.copy(row = (_state.value.selectedCell.row - 1).coerceAtLeast(0)))
    }

    fun insertColumn() {
        updateActiveSheet { sheet, selected ->
            if (sheet.columnCount >= 256) return@updateActiveSheet sheet
            val at = (selected.column + 1).coerceAtMost(255)
            val cells = LinkedHashMap<CellKey, CellContent>()
            sheet.cells.forEach { (key, value) ->
                val column = if (key.column >= at) key.column + 1 else key.column
                if (column <= 255) cells[CellKey(key.row, column)] = value
            }
            sheet.copy(cells = cells, columnCount = (sheet.columnCount + 1).coerceAtMost(256))
        }
    }

    fun deleteColumn() {
        updateActiveSheet { sheet, selected ->
            val cells = LinkedHashMap<CellKey, CellContent>()
            sheet.cells.forEach { (key, value) ->
                when {
                    key.column < selected.column -> cells[key] = value
                    key.column > selected.column -> cells[CellKey(key.row, key.column - 1)] = value
                }
            }
            sheet.copy(cells = cells, columnCount = (sheet.columnCount - 1).coerceAtLeast(1))
        }
        _state.value = _state.value.copy(selectedCell = _state.value.selectedCell.copy(column = (_state.value.selectedCell.column - 1).coerceAtLeast(0)))
    }

    fun search(query: String) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            _state.value = _state.value.copy(searchQuery = query, searchResults = emptyList(), showSearchResults = true)
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, searchQuery = clean, showSearchResults = true, message = null)
            val results = withContext(Dispatchers.IO) { repository.search(fileIndex.all(), clean) }
            _state.value = _state.value.copy(
                isBusy = false,
                searchResults = results,
                showSearchResults = true,
                indexedCount = fileIndex.all().size,
                message = if (results.isEmpty()) "No matches found in ${fileIndex.all().size} indexed file(s)." else "Found ${results.size} matching cell(s)."
            )
        }
    }

    fun openSearchResult(result: SearchResult) {
        val current = _state.value.opened
        if (current?.uri?.toString() == result.uri) {
            val index = current.workbook.sheets.indexOfFirst { it.name == result.sheetName }.coerceAtLeast(0)
            _state.value = _state.value.copy(
                activeSheetIndex = index,
                selectedCell = CellKey(result.rowNumber - 1, result.columnNumber - 1),
                showSearchResults = false
            )
        } else {
            viewModelScope.launch {
                _state.value = _state.value.copy(isBusy = true, showSearchResults = false)
                runCatching {
                    withContext(Dispatchers.IO) { repository.read(Uri.parse(result.uri), result.fileName) }
                }.onSuccess { opened ->
                    fileIndex.add(IndexedFile(result.uri, result.fileName))
                    val index = opened.workbook.sheets.indexOfFirst { it.name == result.sheetName }.coerceAtLeast(0)
                    _state.value = AppUiState(
                        opened = opened,
                        activeSheetIndex = index,
                        selectedCell = CellKey(result.rowNumber - 1, result.columnNumber - 1),
                        indexedCount = fileIndex.all().size,
                        message = "Opened ${result.fileName} at row ${result.rowNumber}."
                    )
                }.onFailure { error ->
                    _state.value = _state.value.copy(isBusy = false, message = error.message ?: "Could not open this search result.")
                }
            }
        }
    }

    fun dismissSearchResults() {
        _state.value = _state.value.copy(showSearchResults = false)
    }

    fun showMessage(message: String) {
        _state.value = _state.value.copy(message = message)
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }

    private fun updateSelectedCell(transform: (CellContent) -> CellContent) {
        updateActiveSheet { sheet, selected ->
            val cells = sheet.cells.toMutableMap()
            val updated = transform(cells[selected] ?: CellContent())
            if (updated.value.isEmpty() && !updated.bold && updated.background == null) cells.remove(selected)
            else cells[selected] = updated
            sheet.copy(cells = cells, rowCount = maxOf(sheet.rowCount, selected.row + 1), columnCount = maxOf(sheet.columnCount, selected.column + 1))
        }
    }

    private fun updateActiveSheet(transform: (SheetModel, CellKey) -> SheetModel) {
        val opened = _state.value.opened ?: return
        val index = _state.value.activeSheetIndex.coerceIn(opened.workbook.sheets.indices)
        val sheets = opened.workbook.sheets.toMutableList()
        sheets[index] = transform(sheets[index], _state.value.selectedCell)
        replaceWorkbook(opened.workbook.copy(sheets = sheets))
    }

    private fun replaceWorkbook(
        workbook: com.miniexcel.app.model.WorkbookModel,
        activeSheet: Int = _state.value.activeSheetIndex,
        selected: CellKey = _state.value.selectedCell
    ) {
        val opened = _state.value.opened ?: return
        _state.value = _state.value.copy(
            opened = opened.copy(workbook = workbook),
            activeSheetIndex = activeSheet.coerceIn(workbook.sheets.indices),
            selectedCell = selected,
            dirty = true,
            message = null
        )
    }
}
