package com.miniexcel.app

import android.app.Application

class MiniExcelApplication : Application()
