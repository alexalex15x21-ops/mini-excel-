package com.miniexcel.app.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.miniexcel.app.model.IndexedFile
import com.miniexcel.app.model.OpenedWorkbook
import com.miniexcel.app.model.SearchResult
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.model.WorkbookModel
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

class SpreadsheetRepository(private val context: Context) {
    private val resolver: ContentResolver = context.contentResolver

    private companion object {
        const val MAX_FILE_BYTES = 50 * 1024 * 1024
    }

    fun displayName(uri: Uri): String {
        val queriedName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index)?.takeIf { it.isNotBlank() }
            } else null
        }
        val fallback = queriedName
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: "Spreadsheet"
        val extension = fallback.substringAfterLast('.', "").lowercase()
        if (extension in setOf("xlsx", "xls", "csv")) return fallback
        val suffix = when (resolver.getType(uri)?.lowercase().orEmpty()) {
            "text/csv", "text/comma-separated-values" -> ".csv"
            "application/vnd.ms-excel" -> ".xls"
            else -> ".xlsx"
        }
        return "$fallback$suffix"
    }

    fun read(uri: Uri, requestedName: String? = null): OpenedWorkbook {
        val name = requestedName?.takeIf { it.isNotBlank() } ?: displayName(uri)
        val bytes = resolver.openInputStream(uri)?.use { input -> readLimited(input, MAX_FILE_BYTES) }
            ?: throw IOException("Android could not open the selected document.")
        val format = formatFor(uri, name)
        val workbook = decode(bytes, name, format)
        return OpenedWorkbook(uri, name, workbook)
    }

    fun createBlank(uri: Uri, name: String, format: SpreadsheetFormat): OpenedWorkbook {
        val safeName = if (name.contains('.')) name else "$name.${format.extension}"
        val workbook = WorkbookModel(
            displayName = safeName,
            format = format,
            sheets = listOf(com.miniexcel.app.model.SheetModel("Sheet1"))
        )
        saveBytes(uri, workbook, format)
        return OpenedWorkbook(uri, displayName(uri).ifBlank { safeName }, workbook.copy(displayName = safeName))
    }

    fun save(opened: OpenedWorkbook): OpenedWorkbook {
        saveBytes(opened.uri, opened.workbook, opened.workbook.format)
        return opened
    }

    fun indexEntry(uri: Uri): IndexedFile = IndexedFile(uri.toString(), displayName(uri))

    private fun formatFor(uri: Uri, name: String): SpreadsheetFormat {
        val extension = name.substringAfterLast('.', "").lowercase()
        if (extension in setOf("xlsx", "xls", "csv")) return SpreadsheetFormat.fromName(name)
        val mime = resolver.getType(uri)?.lowercase().orEmpty()
        return when {
            mime.contains("csv") -> SpreadsheetFormat.CSV
            mime.contains("ms-excel") -> SpreadsheetFormat.XLS
            else -> SpreadsheetFormat.XLSX
        }
    }

    fun search(indexedFiles: List<IndexedFile>, query: String): List<SearchResult> {
        val needle = query.trim().lowercase()
        if (needle.isEmpty()) return emptyList()
        val results = ArrayList<SearchResult>()
        indexedFiles.forEach { indexed ->
            runCatching {
                val opened = read(Uri.parse(indexed.uri), indexed.name)
                opened.workbook.sheets.forEach { sheet ->
                    sheet.cells.forEach { (key, cell) ->
                        if (cell.value.contains(needle, ignoreCase = true)) {
                            results.add(
                                SearchResult(
                                    uri = indexed.uri,
                                    fileName = indexed.name,
                                    sheetName = sheet.name,
                                    rowNumber = key.row + 1,
                                    columnNumber = key.column + 1,
                                    preview = cell.value.take(140)
                                )
                            )
                        }
                    }
                }
            }
        }
        return results.sortedWith(compareBy({ it.fileName.lowercase() }, { it.sheetName.lowercase() }, { it.rowNumber }, { it.columnNumber })).take(5_000)
    }

    private fun saveBytes(uri: Uri, workbook: WorkbookModel, expectedFormat: SpreadsheetFormat?) {
        val format = expectedFormat ?: SpreadsheetFormat.fromName(displayName(uri))
        val encoded = encode(workbook.copy(format = format))
        val stageDirectory = File(context.cacheDir, "save_staging").apply { mkdirs() }
        val staged = File(stageDirectory, "${UUID.randomUUID()}.${format.extension}.tmp")
        val backupDirectory = File(context.filesDir, "recovery_backups").apply { mkdirs() }
        var backup: File? = null
        try {
            FileOutputStream(staged).use { it.write(encoded) }
            decode(staged.readBytes(), workbook.displayName, format)

            val oldBytes = resolver.openInputStream(uri)?.use { readLimited(it, MAX_FILE_BYTES) }
            if (oldBytes != null && oldBytes.isNotEmpty()) {
                backup = File(backupDirectory, "${System.currentTimeMillis()}_${UUID.randomUUID()}.${format.extension}.bak")
                FileOutputStream(backup).use { it.write(oldBytes) }
            }

            try {
                writeDocument(uri, staged)
                val savedBytes = resolver.openInputStream(uri)?.use { readLimited(it, MAX_FILE_BYTES) }
                    ?: throw IOException("The saved document could not be reopened for verification.")
                decode(savedBytes, workbook.displayName, format)
                if (!savedBytes.contentEquals(encoded)) {
                    throw IOException("The document provider changed the saved bytes; the saved file did not pass verification.")
                }
            } catch (writeError: Exception) {
                val backupFile = backup
                if (backupFile != null && backupFile.exists()) {
                    runCatching { writeDocument(uri, backupFile) }
                }
                throw IOException(
                    if (backupFile != null) "Save verification failed. A recovery copy was kept in the app's private storage. ${writeError.message.orEmpty()}"
                    else "Save failed before a recovery copy could be created. ${writeError.message.orEmpty()}",
                    writeError
                )
            }
        } finally {
            staged.delete()
        }
    }

    private fun writeDocument(uri: Uri, file: File) {
        val output = runCatching { resolver.openOutputStream(uri, "rwt") }.getOrNull()
            ?: runCatching { resolver.openOutputStream(uri, "wt") }.getOrNull()
            ?: throw IOException("Android could not write to the selected document.")
        output.use { stream -> file.inputStream().use { input -> input.copyTo(stream) } }
    }

    private fun readLimited(input: java.io.InputStream, limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > limit) throw IOException("This file is larger than the ${limit / (1024 * 1024)} MB Mini Excel limit.")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun encode(workbook: WorkbookModel): ByteArray = when (workbook.format) {
        SpreadsheetFormat.CSV -> CsvCodec.write(workbook)
        SpreadsheetFormat.XLS -> XlsCodec.write(workbook)
        SpreadsheetFormat.XLSX -> XlsxCodec.write(workbook)
    }

    private fun decode(bytes: ByteArray, name: String, format: SpreadsheetFormat): WorkbookModel = when (format) {
        SpreadsheetFormat.CSV -> CsvCodec.read(bytes, name)
        SpreadsheetFormat.XLS -> XlsCodec.read(bytes, name)
        SpreadsheetFormat.XLSX -> XlsxCodec.read(bytes, name)
    }
}
