package com.miniexcel.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.ui.MainViewModel
import com.miniexcel.app.ui.MiniExcelApp
import com.miniexcel.app.ui.theme.MiniExcelTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let {
                persistReadWritePermission(it)
                viewModel.open(it)
            }
        }
        val indexFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEach(::persistReadWritePermission)
            viewModel.indexFiles(uris)
        }
        var pendingName = "New spreadsheet"
        var pendingFormat = SpreadsheetFormat.XLSX
        val createXlsx = registerForActivityResult(
            ActivityResultContracts.CreateDocument(SpreadsheetFormat.XLSX.mimeType)
        ) { uri -> uri?.let { persistReadWritePermission(it); viewModel.create(it, pendingName, pendingFormat) } }
        val createCsv = registerForActivityResult(
            ActivityResultContracts.CreateDocument(SpreadsheetFormat.CSV.mimeType)
        ) { uri -> uri?.let { persistReadWritePermission(it); viewModel.create(it, pendingName, pendingFormat) } }

        setContent {
            MiniExcelTheme {
                MiniExcelApp(
                    viewModel = viewModel,
                    onOpenFile = {
                        openFile.launch(
                            arrayOf(
                                SpreadsheetFormat.XLSX.mimeType,
                                SpreadsheetFormat.XLS.mimeType,
                                SpreadsheetFormat.CSV.mimeType,
                                "text/comma-separated-values"
                            )
                        )
                    },
                    onIndexFiles = {
                        indexFiles.launch(
                            arrayOf(
                                SpreadsheetFormat.XLSX.mimeType,
                                SpreadsheetFormat.XLS.mimeType,
                                SpreadsheetFormat.CSV.mimeType,
                                "text/comma-separated-values"
                            )
                        )
                    },
                    onCreateFile = { name, format ->
                        pendingName = name
                        pendingFormat = format
                        val suggested = if (name.endsWith(".${format.extension}", true)) name else "${name}.${format.extension}"
                        if (format == SpreadsheetFormat.CSV) createCsv.launch(suggested) else createXlsx.launch(suggested)
                    }
                )
            }
        }
    }

    private fun persistReadWritePermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Some providers grant transient access only; the current session can still use it.
        }
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Read-only documents remain searchable and editable until the provider denies save.
        }
    }
}
