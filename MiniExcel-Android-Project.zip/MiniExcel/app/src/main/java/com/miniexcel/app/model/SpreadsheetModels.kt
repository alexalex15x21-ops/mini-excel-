package com.miniexcel.app.model

import android.net.Uri

/** Zero-based row and column coordinate. */
data class CellKey(val row: Int, val column: Int)

data class CellContent(
    val value: String = "",
    val bold: Boolean = false,
    /** RGB hex value without alpha, for example #FFF2CC. */
    val background: String? = null
)

data class SheetModel(
    val name: String,
    val cells: Map<CellKey, CellContent> = emptyMap(),
    val rowCount: Int = 30,
    val columnCount: Int = 16,
    /** OOXML part and relationship metadata; null for newly-created sheets. */
    val sourcePartName: String? = null,
    val relationshipId: String? = null
)

enum class SpreadsheetFormat(val extension: String, val mimeType: String) {
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    XLS("xls", "application/vnd.ms-excel"),
    CSV("csv", "text/csv");

    companion object {
        fun fromName(name: String): SpreadsheetFormat {
            return when (name.substringAfterLast('.', "").lowercase()) {
                "xls" -> XLS
                "csv" -> CSV
                else -> XLSX
            }
        }
    }
}

data class WorkbookModel(
    val displayName: String,
    val format: SpreadsheetFormat,
    val sheets: List<SheetModel>,
    /** Original OOXML package entries, retained so unrelated parts survive a save. */
    val packageParts: Map<String, ByteArray> = emptyMap()
)

data class OpenedWorkbook(
    val uri: Uri,
    val displayName: String,
    val workbook: WorkbookModel
)

data class IndexedFile(val uri: String, val name: String)

data class SearchResult(
    val uri: String,
    val fileName: String,
    val sheetName: String,
    val rowNumber: Int,
    val columnNumber: Int,
    val preview: String
)
