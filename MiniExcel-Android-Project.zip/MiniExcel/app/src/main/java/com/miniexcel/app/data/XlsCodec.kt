package com.miniexcel.app.data

import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.model.WorkbookModel
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.hssf.usermodel.HSSFCellStyle
import org.apache.poi.hssf.usermodel.HSSFFont
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.DateUtil
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale

/** Legacy Excel 97-2003 codec. Uses POI's HSSF module only (no OOXML/desktop UI APIs). */
object XlsCodec {
    fun read(bytes: ByteArray, displayName: String): WorkbookModel {
        val workbook = HSSFWorkbook(ByteArrayInputStream(bytes))
        workbook.use { source ->
            val formatter = DataFormatter(Locale.ROOT)
            val sheets = ArrayList<SheetModel>()
            for (sheetIndex in 0 until source.numberOfSheets) {
                val sourceSheet = source.getSheetAt(sheetIndex)
                val cells = LinkedHashMap<CellKey, CellContent>()
                var maxRow = 0
                var maxColumn = 0
                sourceSheet.rowIterator().forEachRemaining { row ->
                    maxRow = maxOf(maxRow, row.rowNum + 1)
                    row.cellIterator().forEachRemaining { cell ->
                        maxColumn = maxOf(maxColumn, cell.columnIndex + 1)
                        val value = when (cell.cellType) {
                            org.apache.poi.ss.usermodel.CellType.STRING -> cell.stringCellValue
                            org.apache.poi.ss.usermodel.CellType.NUMERIC -> {
                                if (DateUtil.isCellDateFormatted(cell)) formatter.formatCellValue(cell)
                                else formatter.formatCellValue(cell)
                            }
                            org.apache.poi.ss.usermodel.CellType.BOOLEAN -> if (cell.booleanCellValue) "TRUE" else "FALSE"
                            org.apache.poi.ss.usermodel.CellType.FORMULA -> {
                                when (cell.cachedFormulaResultType) {
                                    org.apache.poi.ss.usermodel.CellType.STRING -> cell.stringCellValue
                                    org.apache.poi.ss.usermodel.CellType.NUMERIC -> formatter.formatCellValue(cell)
                                    org.apache.poi.ss.usermodel.CellType.BOOLEAN -> if (cell.booleanCellValue) "TRUE" else "FALSE"
                                    else -> ""
                                }
                            }
                            else -> ""
                        }
                        val cellStyle = cell.cellStyle
                        val font = source.getFontAt(cellStyle.fontIndex)
                        val background = if (cellStyle.fillPattern == FillPatternType.SOLID_FOREGROUND) {
                            val rgb = (cellStyle.fillForegroundColorColor as? org.apache.poi.hssf.util.HSSFColor)?.triplet
                            if (rgb != null && rgb.size >= 3) {
                                "#%02X%02X%02X".format(Locale.ROOT, rgb[0].toInt(), rgb[1].toInt(), rgb[2].toInt())
                            } else null
                        } else null
                        if (value.isNotEmpty() || font.bold || background != null) {
                            cells[CellKey(row.rowNum, cell.columnIndex)] = CellContent(value, font.bold, background)
                        }
                    }
                }
                sheets.add(
                    SheetModel(
                        name = sourceSheet.sheetName,
                        cells = cells,
                        rowCount = maxOf(30, maxRow),
                        columnCount = maxOf(16, maxColumn)
                    )
                )
            }
            if (sheets.isEmpty()) sheets.add(SheetModel("Sheet1"))
            return WorkbookModel(displayName, SpreadsheetFormat.XLS, sheets)
        }
    }

    fun write(workbook: WorkbookModel): ByteArray {
        require(workbook.sheets.isNotEmpty()) { "A workbook must contain at least one sheet." }
        require(workbook.sheets.none { sheet ->
            sheet.cells.keys.any { it.row !in 0..65_535 || it.column !in 0..255 }
        }) { "Legacy XLS supports at most 65,536 rows and 256 columns. Remove or move cells outside that range before saving." }
        val target = HSSFWorkbook()
        target.use { outputWorkbook ->
            val palette = outputWorkbook.getCustomPalette()
            val styleCache = HashMap<Pair<Boolean, String?>, HSSFCellStyle>()
            val fontCache = HashMap<Boolean, HSSFFont>()
            workbook.sheets.forEachIndexed { sheetIndex, model ->
                val sheet = outputWorkbook.createSheet(model.name.take(31).ifBlank { "Sheet${sheetIndex + 1}" })
                model.cells.entries
                    .sortedWith(compareBy({ it.key.row }, { it.key.column }))
                    .forEach { (key, content) ->
                        val row = sheet.getRow(key.row) ?: sheet.createRow(key.row)
                        val cell = row.createCell(key.column)
                        if (isNumeric(content.value)) cell.setCellValue(content.value.toDouble())
                        else cell.setCellValue(content.value)

                        val styleKey = content.bold to normalizeColor(content.background)
                        val style = styleCache.getOrPut(styleKey) {
                            outputWorkbook.createCellStyle().also { newStyle ->
                                newStyle.setFont(fontCache.getOrPut(content.bold) {
                                    outputWorkbook.createFont().also { it.bold = content.bold }
                                })
                                val color = styleKey.second
                                if (color != null) {
                                    val red = color.substring(1, 3).toInt(16)
                                    val green = color.substring(3, 5).toInt(16)
                                    val blue = color.substring(5, 7).toInt(16)
                                    val paletteColor = palette.findSimilarColor(red.toByte(), green.toByte(), blue.toByte())
                                    if (paletteColor != null) {
                                        newStyle.fillForegroundColor = paletteColor.index.toShort()
                                        newStyle.fillPattern = FillPatternType.SOLID_FOREGROUND
                                    }
                                }
                            }
                        }
                        cell.setCellStyle(style)
                    }
            }
            val bytes = ByteArrayOutputStream()
            outputWorkbook.write(bytes)
            return bytes.toByteArray()
        }
    }

    private fun isNumeric(value: String): Boolean {
        if (value.isBlank() || (value.length > 1 && value.startsWith('0') && value[1].isDigit())) return false
        return value.matches(Regex("[-+]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][-+]?\\d+)?"))
    }

    private fun normalizeColor(value: String?): String? {
        val raw = value?.removePrefix("#") ?: return null
        return if (raw.matches(Regex("[0-9A-Fa-f]{6}"))) "#${raw.uppercase(Locale.ROOT)}" else null
    }
}
