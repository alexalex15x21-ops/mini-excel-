package com.miniexcel.app.data

import com.miniexcel.app.model.CellKey
import org.junit.Assert.assertEquals
import org.junit.Test

class CsvCodecTest {
    @Test
    fun quotedFieldsAndEmbeddedNewlinesRoundTrip() {
        val csv = "name,notes\r\n\"A, B\",\"line 1\nline 2\"\r\n\"say \"\"hello\"\"\",42"
        val workbook = CsvCodec.read(csv.toByteArray(), "test.csv")
        val sheet = workbook.sheets.single()
        assertEquals("A, B", sheet.cells[CellKey(1, 0)]?.value)
        assertEquals("line 1\nline 2", sheet.cells[CellKey(1, 1)]?.value)
        assertEquals("say \"hello\"", sheet.cells[CellKey(2, 0)]?.value)
        assertEquals("42", sheet.cells[CellKey(2, 1)]?.value)

        val encoded = CsvCodec.write(workbook)
        val decoded = CsvCodec.read(encoded, "roundtrip.csv")
        assertEquals(sheet.cells, decoded.sheets.single().cells)
    }

    @Test
    fun emptyCsvProducesAnEmptyFile() {
        val workbook = CsvCodec.read(byteArrayOf(), "empty.csv")
        assertEquals(0, CsvCodec.write(workbook).size)
    }
}
