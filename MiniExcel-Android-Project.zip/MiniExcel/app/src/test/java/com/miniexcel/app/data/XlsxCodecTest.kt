package com.miniexcel.app.data

import com.miniexcel.app.model.CellContent
import com.miniexcel.app.model.CellKey
import com.miniexcel.app.model.SheetModel
import com.miniexcel.app.model.SpreadsheetFormat
import com.miniexcel.app.model.WorkbookModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class XlsxCodecTest {
    @Test
    fun newWorkbookCanBeWrittenAndReadWithBasicFormatting() {
        val original = WorkbookModel(
            displayName = "sample.xlsx",
            format = SpreadsheetFormat.XLSX,
            sheets = listOf(
                SheetModel(
                    name = "Data",
                    cells = mapOf(
                        CellKey(0, 0) to CellContent("Name", bold = true, background = "#FFF2CC"),
                        CellKey(0, 1) to CellContent("Amount"),
                        CellKey(1, 0) to CellContent("Coffee & Tea"),
                        CellKey(1, 1) to CellContent("12.5")
                    )
                ),
                SheetModel("Second", cells = mapOf(CellKey(2, 2) to CellContent("A < B")))
            )
        )

        val bytes = XlsxCodec.write(original)
        val decoded = XlsxCodec.read(bytes, "sample.xlsx")
        assertEquals(2, decoded.sheets.size)
        assertEquals("Data", decoded.sheets[0].name)
        assertEquals("Coffee & Tea", decoded.sheets[0].cells[CellKey(1, 0)]?.value)
        assertEquals(true, decoded.sheets[0].cells[CellKey(0, 0)]?.bold)
        assertEquals("#FFF2CC", decoded.sheets[0].cells[CellKey(0, 0)]?.background)
        assertEquals("A < B", decoded.sheets[1].cells[CellKey(2, 2)]?.value)
    }

    @Test
    fun sheetRenameAddAndDeleteMetadataStaysConsistent() {
        val base = WorkbookModel("book.xlsx", SpreadsheetFormat.XLSX, listOf(SheetModel("Old")))
        val encoded = XlsxCodec.write(base)
        val loaded = XlsxCodec.read(encoded, "book.xlsx")
        val updated = loaded.copy(sheets = listOf(loaded.sheets.single().copy(name = "Renamed"), SheetModel("Added")))
        val reread = XlsxCodec.read(XlsxCodec.write(updated), "book.xlsx")
        assertEquals(listOf("Renamed", "Added"), reread.sheets.map { it.name })
        assertFalse(reread.packageParts.isEmpty())
        assertTrue(reread.packageParts.containsKey("xl/worksheets/sheet1.xml"))
    }
}
